-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 03, 2026 at 09:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel_mgmt`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','staff') NOT NULL DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password_hash`, `role`, `created_at`) VALUES
(1, 'Prince Mali', 'prince@hostelmgnt.com', '$2y$10$Je92aKCGSqWJmfPxdgHERe/Bej73ELVMW3dSgA3poZ0eDA4I8Nlam', 'admin', '2026-02-02 18:57:46');

-- --------------------------------------------------------

--
-- Table structure for table `allocations`
--

CREATE TABLE `allocations` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `bed_no` int(11) NOT NULL,
  `checkin_date` date NOT NULL,
  `expected_checkout_date` date DEFAULT NULL,
  `checkout_date` date DEFAULT NULL,
  `allocation_status` enum('active','left') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `allocations`
--

INSERT INTO `allocations` (`id`, `student_id`, `room_id`, `bed_no`, `checkin_date`, `expected_checkout_date`, `checkout_date`, `allocation_status`, `created_at`) VALUES
(1, 3, 4, 1, '2026-02-04', '2026-02-05', '2026-02-03', 'left', '2026-02-02 19:19:48'),
(2, 1, 4, 1, '2026-02-04', '2026-02-04', NULL, 'active', '2026-02-02 19:21:06');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('booked','cancelled','checked_in') NOT NULL DEFAULT 'booked',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `student_id`, `room_id`, `start_date`, `end_date`, `status`, `created_at`) VALUES
(1, 1, 2, '2026-02-05', '2026-02-12', 'booked', '2026-02-02 19:40:57'),
(2, 3, 5, '2026-02-05', '2026-02-07', 'cancelled', '2026-02-02 19:41:37'),
(3, 4, 5, '2026-02-27', '2026-02-28', 'cancelled', '2026-02-02 20:49:33'),
(4, 3, 2, '2026-02-26', '2026-02-28', 'booked', '2026-02-02 21:25:25');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `pay_month` varchar(7) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `paid_date` date DEFAULT NULL,
  `status` enum('paid','due','overdue') NOT NULL DEFAULT 'due',
  `method` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `student_id`, `pay_month`, `amount`, `due_date`, `paid_date`, `status`, `method`, `created_at`) VALUES
(2, 3, '2026-01', 20000.00, '2026-02-01', NULL, 'overdue', NULL, '2026-02-02 19:31:08'),
(3, 1, '2026-02', 8000.00, '2026-02-02', '2026-02-03', 'paid', 'eSewa', '2026-02-02 19:31:43');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `room_no` varchar(20) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `capacity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('available','maintenance') NOT NULL DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_no`, `room_type`, `capacity`, `price`, `status`) VALUES
(2, 'A-102', 'Double', 2, 12000.00, 'available'),
(3, 'B-201', 'Triple', 3, 15000.00, 'maintenance'),
(4, 'A-101', 'Single', 1, 8000.00, 'available'),
(5, 'B-202', 'Triple', 3, 15000.00, 'available');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_id` varchar(30) NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `guardian_phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `password_hash` varchar(255) DEFAULT NULL,
  `can_login` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_id`, `name`, `email`, `phone`, `guardian_phone`, `address`, `status`, `created_at`, `password_hash`, `can_login`) VALUES
(1, '240250', 'Riwaaz Chauguthi', 'riwaaz@hostelmgnt.com', '9709369333', NULL, NULL, 'active', '2026-02-02 19:14:30', NULL, 0),
(3, '2402566', 'Anil Sharma', 'anil@hostelmgnt.com', '9709369334', NULL, NULL, 'active', '2026-02-02 19:19:10', '$2y$10$vlrnpuzuGqWwuIVx8QYO0eTBfd8LX45wAeNJDh/v8DocSNM7Van5a', 1),
(4, '2402565', 'Baibhav Bista', 'baibhav@hostelmgnt.com', '9709369444', NULL, NULL, 'active', '2026-02-02 20:07:14', '$2y$10$Mbo2v.PavdOQWy2gnfjVcOzvbkDeUfQw51wsC/6kggQVGjwMgUVKq', 1),
(5, 'STU26020309130139', 'Nijal Maharjan', 'test@example.com', '', '', '', 'active', '2026-02-03 08:13:01', '$2y$10$wQvkewxi7ss6CRv9pRDk8OEmJchko54VH8kPr8oLuxj7L5gRX8D.S', 1),
(6, 'STU26020309140015', 'Bharat Gautam', 'bharat@hostel.com', '', '', '', 'active', '2026-02-03 08:14:00', '$2y$10$oofYooy/2M5lrTfKbWwHveLcgJQhdmFoM0pgoPZvkEJ4pEaZbFehG', 1),
(7, 'STU26020309154924', 'Rita Lama', 'rita@hostel.com', '', '', '', 'active', '2026-02-03 08:15:49', '$2y$10$QnH6dt95GiqTwlMpUvfw8eXlj364XsWwKi5mQWcnCamGeabUpK.9W', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `allocations`
--
ALTER TABLE `allocations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_student_active_alloc` (`student_id`,`allocation_status`),
  ADD UNIQUE KEY `uq_room_bed_active` (`room_id`,`bed_no`,`allocation_status`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_booking_student` (`student_id`),
  ADD KEY `idx_booking_room_dates` (`room_id`,`start_date`,`end_date`,`status`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pay_student` (`student_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `room_no` (`room_no`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `uniq_students_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `allocations`
--
ALTER TABLE `allocations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `allocations`
--
ALTER TABLE `allocations`
  ADD CONSTRAINT `fk_alloc_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_alloc_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_booking_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_booking_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_pay_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
