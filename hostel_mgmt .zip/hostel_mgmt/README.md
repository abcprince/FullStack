# Hostel Management System

## Project Overview
This Hostel Management System is a web-based application developed using **PHP, MySQL, HTML, CSS, JavaScript (AJAX)**.

It allows hostel administrators to manage students, rooms, allocations, payments, and bookings. Students can log in separately to manage **their own bookings only**.

---

## Live Access / URLs
- **Landing Page:** `/hostel_mgmt/public/landing.php`
- **Admin/Staff Login:** `/hostel_mgmt/public/login.php`
- **Student Login:** `/hostel_mgmt/public/student_login.php`

> If hosted on the college server, use the provided hosted URL + same page paths.

---

## Login Credentials (for Evaluation)

### Admin / Staff
- **Email:** `prince@inventorymgnt.com`
- **Password:** `admin123`

### Student
- **Student Email:** `test@example.com`
- **Password:** `nijal12`

---

## Setup Instructions (Local - XAMPP)

### Requirements
- XAMPP (Apache + MySQL)
- PHP 8+
- Web browser

### Steps
1. Copy the project folder to: htdocs/hostel_mgnt

2. Start **Apache** and **MySQL** in XAMPP.
3. Create/import database in phpMyAdmin:
- Database name: `hostel_mgmt`
- Import the provided SQL file (tables + sample data).
4. Check database connection file:
- `config/db.php`
5. Open: http://localhost/hostel_mgmt/public/landing.php


---

## Hosted Deployment Notes (College Server)
This system is intended to be hosted with a **pre-configured database**.
- Teachers **do not need** to create a database or run SQL scripts.
- Teachers can directly log in using the credentials above.

---

## Implemented Features

### Authentication & Roles
- Admin/Staff login (session-based)
- Student login (separate portal)
- Role-based access control (students cannot access admin pages)
- Logout for both roles

### Admin Modules (CRUD)
- **Students CRUD**
- Add / Edit / Delete / View
- Enable/disable student login + set student password
- **Rooms CRUD**
- Add / Edit / Delete / View
- Capacity & price tracking
- **Allocations (Check-in / Checkout)**
- Assign student to room/bed
- Checkout and free bed
- **Payments CRUD**
- Record payments
- Track status: Paid/Due/Overdue
- **Bookings**
- Admin can view booking records

### Search (Mandatory)
- Search students / rooms / payments (implemented via search page)

### AJAX (Mandatory)
- Real-time room availability checking for bookings (dynamic dropdown updates)

### Security (Mandatory)
- Prepared statements (PDO)
- Password hashing (`password_hash`)
- Output escaping (`htmlspecialchars`)
- CSRF protection on POST forms
- Server-side validation
- Session route protection

---

## Known Issues (if any)
- Mobile responsiveness is basic (desktop-first UI).
- No email notifications (out of scope).
- Booking calendar is list-based (not a full visual calendar UI).

---