<?php
// config/session.php
// Purpose: Start sessions with safer cookie settings (helps reduce hijacking/CSRF)

if (session_status() === PHP_SESSION_NONE) {
  session_set_cookie_params([
    'httponly' => true,      // JS can't access session cookie
    'samesite' => 'Lax',     // reduces CSRF risk
    'secure'   => false      // set true only when using HTTPS (student server later)
  ]);

  session_start();
}