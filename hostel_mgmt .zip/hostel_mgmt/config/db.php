<?php
// config/db.php
// Purpose: Create a reusable PDO connection to MySQL (used by all pages)

$host = 'localhost';
$db   = 'NP03CS4A240354';
$user = 'NP03CS4A240354';
$pass = 'dGhfh5CUwa'; // XAMPP default is empty unless you set one
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
  PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // throw exceptions on errors
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // fetch as associative arrays
  PDO::ATTR_EMULATE_PREPARES   => false,                  // real prepared statements
];

try {
  $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
  // In production you'd log the error; here we keep message generic for security
  die("Database connection failed.");
}