<?php
// includes/header.php
// Purpose: Reusable page header + loads CSS

require_once __DIR__ . '/../config/session.php';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle ?? 'Hostel Management') ?></title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
  <div class="nav">
    <div class="container">
      <a class="brand" href="index.php">Hostel Management</a>
      <div>
        <?php if (!empty($_SESSION['user_id'])): ?>
          <a class="btn secondary" href="logout.php">Logout</a>
        <?php else: ?>
          <a class="btn secondary" href="login.php">Login</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="container"></div>