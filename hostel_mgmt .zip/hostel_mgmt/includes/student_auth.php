<?php
// includes/student_auth.php
// Purpose: Protect student-only pages

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

function require_student_login(): void {
  if (($_SESSION['user_type'] ?? '') !== 'student' || empty($_SESSION['student_db_id'])) {
    header("Location: /hostel_mgmt/public/student_login.php");
    exit;
  }
}