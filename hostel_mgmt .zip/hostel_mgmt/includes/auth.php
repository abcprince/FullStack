<?php
// includes/auth.php
// Purpose: Block access to pages unless the user is logged in

require_once __DIR__ . '/../config/session.php';

function require_login(): void {
  if (empty($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
  }
}