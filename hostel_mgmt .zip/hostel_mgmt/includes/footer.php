<?php
// includes/footer.php
// Purpose: Reusable page footer
?>
  </div>
</body>
</html>