<?php
// includes/csrf.php
// Purpose: Generate and validate CSRF tokens to protect POST requests

require_once __DIR__ . '/../config/session.php';

/**
 * Create a CSRF token and store it in session (if not already set).
 */
function csrf_token(): string {
  if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
  }
  return $_SESSION['csrf_token'];
}

/**
 * Validate a posted CSRF token.
 */
function csrf_validate(?string $token): bool {
  if (empty($_SESSION['csrf_token']) || empty($token)) return false;
  return hash_equals($_SESSION['csrf_token'], $token);
}