<?php
// includes/sidebar.php
// Purpose: Reusable sidebar navigation for logged-in pages

$current = basename($_SERVER['PHP_SELF']); // current page filename

function nav_link(string $file, string $label, string $current): string {
  $active = ($file === $current) ? 'active' : '';
  return '<a class="'.$active.'" href="'.$file.'">'.htmlspecialchars($label).'</a>';
}
?>

<div class="sidebar">
  <?= nav_link('index.php', 'Dashboard', $current) ?>
  <?= nav_link('students.php', 'Students', $current) ?>
  <?= nav_link('rooms.php', 'Rooms', $current) ?>
  <?= nav_link('allocations.php', 'Allocations', $current) ?>
  <?= nav_link('payments.php', 'Payments', $current) ?>
  <?= nav_link('search.php', 'Search', $current) ?>
  <hr style="border:none;border-top:1px solid var(--border);margin:10px 0;">
  <?= nav_link('logout.php', 'Logout', $current) ?>
  <?= nav_link('availability.php', 'Availability (Ajax)', $current) ?>
  <?= nav_link('bookings.php', 'Bookings (Calendar)', $current) ?>
</div>