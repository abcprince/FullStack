<?php
// public/booking_add.php
// Purpose: Create a new booking with date range and prevent conflicts (no overlap in same room).

$pageTitle = "New Booking";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';

// Students dropdown
$students = $pdo->query("SELECT id, student_id, name FROM students WHERE status='active' ORDER BY name ASC")->fetchAll();

// Room types dropdown
$roomTypes = $pdo->query("SELECT DISTINCT room_type FROM rooms ORDER BY room_type ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $room_id    = (int)($_POST['room_id'] ?? 0);
    $start_date = $_POST['start_date'] ?? '';
    $end_date   = $_POST['end_date'] ?? '';

    if ($student_id <= 0 || $room_id <= 0 || $start_date === '' || $end_date === '') {
      $error = "Student, room, start date, and end date are required.";
    } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
      $error = "Invalid date format.";
    } elseif (strtotime($end_date) < strtotime($start_date)) {
      $error = "End date cannot be before start date.";
    } else {
      // Conflict check: overlapping booking for same room in booked/checked_in
      $conf = $pdo->prepare("
        SELECT COUNT(*) AS c
        FROM bookings
        WHERE room_id = ?
          AND status IN ('booked','checked_in')
          AND start_date <= ?
          AND end_date >= ?
      ");
      $conf->execute([$room_id, $end_date, $start_date]);
      if ((int)($conf->fetch()['c'] ?? 0) > 0) {
        $error = "This room is already booked for the selected date range.";
      } else {
        // Insert booking
        $ins = $pdo->prepare("INSERT INTO bookings (student_id, room_id, start_date, end_date, status) VALUES (?, ?, ?, ?, 'booked')");
        $ins->execute([$student_id, $room_id, $start_date, $end_date]);
        header("Location: bookings.php");
        exit;
      }
    }
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">New Booking</h2>
      <p class="muted" style="margin:6px 0 0 0;">Reserve a room for a date range. Conflicts are blocked.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:850px;">
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div class="form-row">
          <label>Student</label>
          <select name="student_id" required>
            <option value="">-- Select Student --</option>
            <?php foreach ($students as $s): ?>
              <option value="<?= (int)$s['id'] ?>">
                <?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['student_id']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          <div class="form-row">
            <label>Start Date</label>
            <input id="startDate" type="date" name="start_date" required>
          </div>

          <div class="form-row">
            <label>End Date</label>
            <input id="endDate" type="date" name="end_date" required>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          <div class="form-row">
            <label>Room Type (filter)</label>
            <select id="roomTypeFilter">
              <option value="">All Types</option>
              <?php foreach ($roomTypes as $t): ?>
                <option value="<?= htmlspecialchars($t['room_type']) ?>"><?= htmlspecialchars($t['room_type']) ?></option>
              <?php endforeach; ?>
            </select>
            <p class="muted" style="margin:6px 0 0 0;">This filter helps you find rooms quickly.</p>
          </div>

          <div class="form-row">
            <label>Available Rooms (for selected dates)</label>
            <select id="roomSelect" name="room_id" required>
              <option value="">Select dates first...</option>
            </select>
          </div>
        </div>

        <button class="btn" type="submit">Create Booking</button>
        <a class="btn secondary" href="bookings.php">Cancel</a>
      </form>
    </div>
  </div>
</div>

<script>
// Purpose: Use Fetch (Ajax) to load available rooms for the selected date range.
// Uses ajax_available_rooms.php with start_date + end_date

const startEl = document.getElementById('startDate');
const endEl = document.getElementById('endDate');
const typeEl = document.getElementById('roomTypeFilter');
const roomEl = document.getElementById('roomSelect');

async function loadRooms() {
  const start = startEl.value;
  const end = endEl.value;
  const type = typeEl.value;

  roomEl.innerHTML = `<option value="">Loading...</option>`;

  if (!start || !end) {
    roomEl.innerHTML = `<option value="">Select dates first...</option>`;
    return;
  }

  const params = new URLSearchParams();
  params.append('start_date', start);
  params.append('end_date', end);
  if (type) params.append('room_type', type);

  try {
    const res = await fetch('ajax_available_rooms.php?' + params.toString());
    const data = await res.json();

    if (!data.ok) {
      roomEl.innerHTML = `<option value="">Error loading rooms</option>`;
      return;
    }

    if (data.rooms.length === 0) {
      roomEl.innerHTML = `<option value="">No rooms available for these dates</option>`;
      return;
    }

    roomEl.innerHTML = `<option value="">-- Select Room --</option>`;
    for (const r of data.rooms) {
      const opt = document.createElement('option');
      opt.value = r.id;
      opt.textContent = `${r.room_no} - ${r.room_type} (beds avail: ${r.beds_available})`;
      roomEl.appendChild(opt);
    }
  } catch (e) {
    roomEl.innerHTML = `<option value="">Error loading rooms</option>`;
  }
}

startEl.addEventListener('change', loadRooms);
endEl.addEventListener('change', loadRooms);
typeEl.addEventListener('change', loadRooms);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>