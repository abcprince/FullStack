<?php
// public/allocation_checkout.php
// Purpose: Checkout a student (set allocation_status to 'left' and store checkout_date)

$pageTitle = "Checkout";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
  die("Invalid allocation ID.");
}

// Fetch allocation with student + room details
$stmt = $pdo->prepare("
  SELECT a.*, s.name AS student_name, s.student_id AS sid, r.room_no
  FROM allocations a
  JOIN students s ON s.id = a.student_id
  JOIN rooms r ON r.id = a.room_id
  WHERE a.id = ?
");
$stmt->execute([$id]);
$alloc = $stmt->fetch();

if (!$alloc) {
  die("Allocation not found.");
}

if ($alloc['allocation_status'] !== 'active') {
  die("This allocation is already checked out.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $checkout = $_POST['checkout_date'] ?? '';

    if ($checkout === '') {
      $error = "Checkout date is required.";
    } else {
      $upd = $pdo->prepare("UPDATE allocations SET allocation_status='left', checkout_date=? WHERE id=?");
      $upd->execute([$checkout, $id]);

      header("Location: allocations.php");
      exit;
    }
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Checkout Student</h2>
      <p class="muted" style="margin:6px 0 0 0;">
        <?= htmlspecialchars($alloc['student_name']) ?> (<?= htmlspecialchars($alloc['sid']) ?>) —
        Room <?= htmlspecialchars($alloc['room_no']) ?>, Bed <?= (int)$alloc['bed_no'] ?>
      </p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:650px;">
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div class="form-row">
          <label>Checkout Date</label>
          <input type="date" name="checkout_date" required>
        </div>

        <button class="btn" type="submit">Confirm Checkout</button>
        <a class="btn secondary" href="allocations.php">Cancel</a>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>