<?php
// public/payment_edit.php
// Purpose: Edit an existing payment record (mark paid, change due date, etc.)

$pageTitle = "Edit Payment";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) die("Invalid payment ID.");

$stmt = $pdo->prepare("SELECT * FROM payments WHERE id=?");
$stmt->execute([$id]);
$payment = $stmt->fetch();

if (!$payment) die("Payment not found.");

$students = $pdo->query("SELECT id, student_id, name FROM students ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $pay_month  = trim($_POST['pay_month'] ?? '');
    $amount     = (float)($_POST['amount'] ?? 0);
    $due_date   = $_POST['due_date'] ?? '';
    $paid_date  = $_POST['paid_date'] ?? '';
    $status     = $_POST['status'] ?? 'due';
    $method     = trim($_POST['method'] ?? '');

    $allowed = ['paid','due','overdue'];

    if ($student_id <= 0 || $pay_month === '' || $due_date === '' || $amount <= 0) {
      $error = "Student, month, amount, and due date are required.";
    } elseif (!preg_match('/^\d{4}-\d{2}$/', $pay_month)) {
      $error = "Month must be in YYYY-MM format.";
    } elseif (!in_array($status, $allowed, true)) {
      $error = "Invalid status selected.";
    } elseif ($status === 'paid' && $paid_date === '') {
      $error = "Paid date is required when status is Paid.";
    } else {
      $sql = "UPDATE payments
              SET student_id=?, pay_month=?, amount=?, due_date=?, paid_date=?, status=?, method=?
              WHERE id=?";
      $upd = $pdo->prepare($sql);

      $upd->execute([
        $student_id,
        $pay_month,
        $amount,
        $due_date,
        ($paid_date !== '' ? $paid_date : null),
        $status,
        ($method !== '' ? $method : null),
        $id
      ]);

      header("Location: payments.php");
      exit;
    }
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Edit Payment</h2>
      <p class="muted" style="margin:6px 0 0 0;">Update payment record.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:750px;">
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div class="form-row">
          <label>Student</label>
          <select name="student_id" required>
            <?php foreach ($students as $s): ?>
              <option value="<?= (int)$s['id'] ?>" <?= ((int)$payment['student_id'] === (int)$s['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['student_id']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-row">
          <label>Month</label>
          <input type="month" name="pay_month" value="<?= htmlspecialchars($payment['pay_month']) ?>" required>
        </div>

        <div class="form-row">
          <label>Amount</label>
          <input type="number" name="amount" step="0.01" min="0" value="<?= htmlspecialchars($payment['amount']) ?>" required>
        </div>

        <div class="form-row">
          <label>Due Date</label>
          <input type="date" name="due_date" value="<?= htmlspecialchars($payment['due_date']) ?>" required>
        </div>

        <div class="form-row">
          <label>Paid Date</label>
          <input type="date" name="paid_date" value="<?= htmlspecialchars($payment['paid_date'] ?? '') ?>">
        </div>

        <div class="form-row">
          <label>Status</label>
          <select name="status">
            <option value="due" <?= $payment['status']==='due'?'selected':'' ?>>Due</option>
            <option value="paid" <?= $payment['status']==='paid'?'selected':'' ?>>Paid</option>
            <option value="overdue" <?= $payment['status']==='overdue'?'selected':'' ?>>Overdue</option>
          </select>
        </div>

        <div class="form-row">
          <label>Method</label>
          <input type="text" name="method" value="<?= htmlspecialchars($payment['method'] ?? '') ?>">
        </div>

        <button class="btn" type="submit">Update Payment</button>
        <a class="btn secondary" href="payments.php">Cancel</a>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>