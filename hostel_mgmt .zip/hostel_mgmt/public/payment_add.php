<?php
// public/payment_add.php
// Purpose: Add a payment record securely (CSRF + validation + prepared statements)

$pageTitle = "Add Payment";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';

// Students dropdown
$students = $pdo->query("SELECT id, student_id, name FROM students ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $pay_month  = trim($_POST['pay_month'] ?? ''); // format YYYY-MM
    $amount     = (float)($_POST['amount'] ?? 0);
    $due_date   = $_POST['due_date'] ?? '';
    $paid_date  = $_POST['paid_date'] ?? '';
    $status     = $_POST['status'] ?? 'due';
    $method     = trim($_POST['method'] ?? '');

    $allowed = ['paid','due','overdue'];

    if ($student_id <= 0 || $pay_month === '' || $due_date === '' || $amount <= 0) {
      $error = "Student, month, amount, and due date are required.";
    } elseif (!preg_match('/^\d{4}-\d{2}$/', $pay_month)) {
      $error = "Month must be in YYYY-MM format.";
    } elseif (!in_array($status, $allowed, true)) {
      $error = "Invalid status selected.";
    } else {
      // If paid, paid_date should be provided (recommended)
      if ($status === 'paid' && $paid_date === '') {
        $error = "Paid date is required when status is Paid.";
      } else {
        $sql = "INSERT INTO payments (student_id, pay_month, amount, due_date, paid_date, status, method)
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);

        try {
          $stmt->execute([
            $student_id,
            $pay_month,
            $amount,
            $due_date,
            ($paid_date !== '' ? $paid_date : null),
            $status,
            ($method !== '' ? $method : null),
          ]);
          header("Location: payments.php");
          exit;
        } catch (PDOException $e) {
          $error = "Could not add payment. Please try again.";
        }
      }
    }
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Add Payment</h2>
      <p class="muted" style="margin:6px 0 0 0;">Record rent/payment for a student.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:750px;">
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div class="form-row">
          <label>Student</label>
          <select name="student_id" required>
            <option value="">-- Select Student --</option>
            <?php foreach ($students as $s): ?>
              <option value="<?= (int)$s['id'] ?>">
                <?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['student_id']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-row">
          <label>Month (YYYY-MM)</label>
          <input type="month" name="pay_month" required>
        </div>

        <div class="form-row">
          <label>Amount</label>
          <input type="number" name="amount" step="0.01" min="0" required>
        </div>

        <div class="form-row">
          <label>Due Date</label>
          <input type="date" name="due_date" required>
        </div>

        <div class="form-row">
          <label>Paid Date (optional)</label>
          <input type="date" name="paid_date">
        </div>

        <div class="form-row">
          <label>Status</label>
          <select name="status">
            <option value="due">Due</option>
            <option value="paid">Paid</option>
            <option value="overdue">Overdue</option>
          </select>
        </div>

        <div class="form-row">
          <label>Payment Method (optional)</label>
          <input type="text" name="method" placeholder="Cash / Bank / eSewa ...">
        </div>

        <button class="btn" type="submit">Save Payment</button>
        <a class="btn secondary" href="payments.php">Cancel</a>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>