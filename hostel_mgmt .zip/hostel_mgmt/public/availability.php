<?php
// public/availability.php
// Purpose: Real-time room availability check using Fetch API (Ajax)

$pageTitle = "Availability Check";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';

// Fetch distinct room types for dropdown
$types = $pdo->query("SELECT DISTINCT room_type FROM rooms ORDER BY room_type ASC")->fetchAll();
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Real-time Availability</h2>
      <p class="muted" style="margin:6px 0 0 0;">
        Filter rooms by type/capacity. Results update instantly (Ajax).
      </p>
    </div>

    <div class="card" style="margin-bottom:12px;max-width:850px;">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div>
          <label>Room Type</label>
          <select id="roomType">
            <option value="">All Types</option>
            <?php foreach ($types as $t): ?>
              <option value="<?= htmlspecialchars($t['room_type']) ?>"><?= htmlspecialchars($t['room_type']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label>Minimum Capacity</label>
          <input id="minCap" type="number" min="0" value="0" placeholder="e.g. 2">
        </div>
      </div>

      <div style="margin-top:12px;">
        <button class="btn" id="checkBtn" type="button">Check Availability</button>
      </div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Available Rooms</h3>
      <p class="muted" id="resultMeta">Use filters above and click “Check Availability”.</p>

      <div id="results" style="overflow:auto;"></div>
    </div>
  </div>
</div>

<script>
// Purpose: Fetch available rooms from PHP endpoint and render results

const roomTypeEl = document.getElementById('roomType');
const minCapEl   = document.getElementById('minCap');
const resultsEl  = document.getElementById('results');
const metaEl     = document.getElementById('resultMeta');
const btn        = document.getElementById('checkBtn');

async function fetchAvailableRooms() {
  const room_type = roomTypeEl.value.trim();
  const min_capacity = parseInt(minCapEl.value || "0", 10);

  // Build query string
  const params = new URLSearchParams();
  if (room_type) params.append('room_type', room_type);
  if (!isNaN(min_capacity) && min_capacity > 0) params.append('min_capacity', String(min_capacity));

  metaEl.textContent = "Loading...";
  resultsEl.innerHTML = "";

  try {
    const res = await fetch("ajax_available_rooms.php?" + params.toString(), {
      headers: { "Accept": "application/json" }
    });
    const data = await res.json();

    if (!data.ok) {
      metaEl.textContent = "Could not fetch results.";
      return;
    }

    metaEl.textContent = `Found ${data.count} available room(s).`;

    if (data.rooms.length === 0) {
      resultsEl.innerHTML = `<p class="muted">No rooms match your filters.</p>`;
      return;
    }

    // Render as a table
    let html = `
      <table style="width:100%;border-collapse:collapse;">
        <thead>
          <tr>
            <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Room No</th>
            <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Type</th>
            <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Capacity</th>
            <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Beds Available</th>
            <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Price</th>
          </tr>
        </thead>
        <tbody>
    `;

    for (const r of data.rooms) {
      html += `
        <tr>
          <td style="padding:10px;border-bottom:1px solid var(--border);">${escapeHtml(r.room_no)}</td>
          <td style="padding:10px;border-bottom:1px solid var(--border);">${escapeHtml(r.room_type)}</td>
          <td style="padding:10px;border-bottom:1px solid var(--border);">${Number(r.capacity)}</td>
          <td style="padding:10px;border-bottom:1px solid var(--border);">${Number(r.beds_available)}</td>
          <td style="padding:10px;border-bottom:1px solid var(--border);">${Number(r.price).toFixed(2)}</td>
        </tr>
      `;
    }

    html += `</tbody></table>`;
    resultsEl.innerHTML = html;

  } catch (e) {
    metaEl.textContent = "Error fetching availability.";
  }
}

// Small helper to prevent HTML injection in JS rendering
function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

// Button click triggers fetch
btn.addEventListener('click', fetchAvailableRooms);

// Optional: live refresh when filters change
roomTypeEl.addEventListener('change', fetchAvailableRooms);
minCapEl.addEventListener('input', () => {
  // Debounce a bit (simple)
  clearTimeout(window.__availTimer);
  window.__availTimer = setTimeout(fetchAvailableRooms, 300);
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>