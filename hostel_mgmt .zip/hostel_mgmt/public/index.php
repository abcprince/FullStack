<?php
// public/index.php
// Purpose: Dashboard showing hostel summary stats (students, rooms, occupancy, payments)

$pageTitle = "Dashboard";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';

// ----- Queries for dashboard stats -----
// Total students
$studentsTotal = (int)($pdo->query("SELECT COUNT(*) AS c FROM students")->fetch()['c'] ?? 0);

// Total rooms
$roomsTotal = (int)($pdo->query("SELECT COUNT(*) AS c FROM rooms")->fetch()['c'] ?? 0);

// Active allocations = occupied beds (students currently living)
$occupiedBeds = (int)($pdo->query("SELECT COUNT(*) AS c FROM allocations WHERE allocation_status='active'")->fetch()['c'] ?? 0);

// Available beds calculation:
// Sum of all room capacities - occupied active allocations
$totalBeds = (int)($pdo->query("SELECT COALESCE(SUM(capacity),0) AS s FROM rooms")->fetch()['s'] ?? 0);
$availableBeds = max(0, $totalBeds - $occupiedBeds);

// Pending payments (due + overdue)
$pendingPayments = (int)($pdo->query("SELECT COUNT(*) AS c FROM payments WHERE status IN ('due','overdue')")->fetch()['c'] ?? 0);

// Overdue payments count
$overduePayments = (int)($pdo->query("SELECT COUNT(*) AS c FROM payments WHERE status='overdue'")->fetch()['c'] ?? 0);

// Recent allocations (last 5)
$recentAllocStmt = $pdo->query("
  SELECT a.id, s.name AS student_name, r.room_no, a.bed_no, a.checkin_date
  FROM allocations a
  JOIN students s ON s.id = a.student_id
  JOIN rooms r ON r.id = a.room_id
  ORDER BY a.created_at DESC
  LIMIT 5
");
$recentAllocations = $recentAllocStmt->fetchAll();
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'User') ?> 👋</h2>
      <p class="muted" style="margin:6px 0 0 0;">Here’s a quick overview of your hostel.</p>
    </div>

    <div class="grid-cards" style="margin-bottom:12px;">
      <div class="card">
        <h3>Total Students</h3>
        <div class="big-number"><?= $studentsTotal ?></div>
        <div class="muted">Registered occupants</div>
      </div>

      <div class="card">
        <h3>Total Rooms</h3>
        <div class="big-number"><?= $roomsTotal ?></div>
        <div class="muted">Rooms in the hostel</div>
      </div>

      <div class="card">
        <h3>Available Beds</h3>
        <div class="big-number"><?= $availableBeds ?></div>
        <div class="muted">Out of <?= $totalBeds ?> total beds</div>
      </div>

      <div class="card">
        <h3>Pending Payments</h3>
        <div class="big-number"><?= $pendingPayments ?></div>
        <div class="muted"><?= $overduePayments ?> overdue</div>
      </div>
    </div>

    <div class="card">
      <h3>Recent Check-ins</h3>

      <?php if (empty($recentAllocations)): ?>
        <p class="muted">No allocations yet. Once you allocate students to rooms, they will appear here.</p>
      <?php else: ?>
        <div style="overflow:auto;">
          <table style="width:100%;border-collapse:collapse;">
            <thead>
              <tr>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Student</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Room</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Bed</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Check-in</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recentAllocations as $row): ?>
                <tr>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($row['student_name']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($row['room_no']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= (int)$row['bed_no'] ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($row['checkin_date']) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>