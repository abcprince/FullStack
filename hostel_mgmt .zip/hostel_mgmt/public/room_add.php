<?php
// public/room_add.php
// Purpose: Add a new room using POST + CSRF + validation + prepared statements

$pageTitle = "Add Room";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // 1) CSRF check
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    // 2) Read & validate inputs
    $room_no   = trim($_POST['room_no'] ?? '');
    $room_type = trim($_POST['room_type'] ?? '');
    $capacity  = (int)($_POST['capacity'] ?? 0);
    $price     = (float)($_POST['price'] ?? 0);
    $status    = $_POST['status'] ?? 'available';

    if ($room_no === '' || $room_type === '') {
      $error = "Room number and room type are required.";
    } elseif ($capacity <= 0) {
      $error = "Capacity must be greater than 0.";
    } elseif (!in_array($status, ['available', 'maintenance'], true)) {
      $error = "Invalid status selected.";
    } else {
      // 3) Insert using prepared statement
      $sql = "INSERT INTO rooms (room_no, room_type, capacity, price, status) VALUES (?, ?, ?, ?, ?)";
      $stmt = $pdo->prepare($sql);

      try {
        $stmt->execute([$room_no, $room_type, $capacity, $price, $status]);
        header("Location: rooms.php");
        exit;
      } catch (PDOException $e) {
        // Most likely duplicate room_no
        $error = "Could not add room. Room number may already exist.";
      }
    }
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Add Room</h2>
      <p class="muted" style="margin:6px 0 0 0;">Create a new room record.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:650px;">
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div class="form-row">
          <label>Room Number</label>
          <input type="text" name="room_no" placeholder="e.g. A-101" required>
        </div>

        <div class="form-row">
          <label>Room Type</label>
          <input type="text" name="room_type" placeholder="e.g. Single / Double / Deluxe" required>
        </div>

        <div class="form-row">
          <label>Capacity (beds)</label>
          <input type="number" name="capacity" min="1" required>
        </div>

        <div class="form-row">
          <label>Price (monthly)</label>
          <input type="number" name="price" step="0.01" min="0" value="0">
        </div>

        <div class="form-row">
          <label>Status</label>
          <select name="status">
            <option value="available">Available</option>
            <option value="maintenance">Maintenance</option>
          </select>
        </div>

        <button class="btn" type="submit">Save Room</button>
        <a class="btn secondary" href="rooms.php">Cancel</a>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>