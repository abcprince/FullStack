<?php
// public/student_login.php
// Purpose: Student login using email + password

session_start();

require_once __DIR__ . '/../config/db.php';

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';

  if ($email === '' || $password === '') {
    $error = "Email and password are required.";
  } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error = "Please enter a valid email address.";
  } else {
    $stmt = $pdo->prepare("
      SELECT * FROM students
      WHERE email = ? AND can_login = 1 AND status = 'active'
      LIMIT 1
    ");
    $stmt->execute([$email]);
    $student = $stmt->fetch();

    if (!$student || !password_verify($password, $student['password_hash'])) {
      $error = "Invalid email or password.";
    } else {
      // Login successful
      $_SESSION['user_type'] = 'student';
      $_SESSION['student_db_id'] = $student['id'];
      $_SESSION['student_name'] = $student['name'];
      $_SESSION['student_email'] = $student['email'];

      header("Location: ../public/student/dashboard.php");
      exit;
    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Login</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
  <div class="container" style="max-width:520px;margin-top:40px;">
    <div class="card">
      <h2 style="margin-top:0;">Student Login</h2>

      <?php if ($error): ?>
        <div class="alert"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST">
        <div class="form-row">
          <label>Email</label>
          <input type="email" name="email" required>
        </div>

        <div class="form-row">
          <label>Password</label>
          <input type="password" name="password" required>
        </div>

        <button class="btn" type="submit">Login</button>
        <a class="btn secondary" href="/hostel_mgmt/public/login.php">Admin/Staff Login</a>
        <a class="btn secondary" href="landing.php">Home</a>

        <p class="muted" style="margin-top:12px;">
          Don’t have an account?
          <a href="../public/student_register.php">Register here</a>
        </p>
      </form>
    </div>
  </div>
</body>
</html>