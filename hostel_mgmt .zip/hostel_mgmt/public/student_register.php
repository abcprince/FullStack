<?php
// public/student_register.php
// Purpose: Allow anyone to register as a student (simple school-project flow)

session_start();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';

$error = '';
$success = '';

$name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Validation
    if ($name === '' || $email === '' || $password === '') {
      $error = "Full name, email, and password are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $error = "Please enter a valid email address.";
    } elseif (strlen($password) < 5) {
      $error = "Password must be at least 5 characters.";
    } else {
      try {
        // Check if email exists
        $chk = $pdo->prepare("SELECT id FROM students WHERE email = ? LIMIT 1");
        $chk->execute([$email]);
        if ($chk->fetch()) {
          $error = "This email is already registered. Please login instead.";
        } else {
          $hash = password_hash($password, PASSWORD_BCRYPT);

          // Insert student (student_id generated after insert)
          $generatedStudentId = 'STU' . date('ymdHis') . rand(10,99);

            $ins = $pdo->prepare("
              INSERT INTO students (
                student_id,
                name,
                email,
                phone,
                guardian_phone,
                address,
                status,
                can_login,
                password_hash
              ) VALUES (
                ?, ?, ?, '', '', '', 'active', 1, ?
              )
            ");
            $ins->execute([
              $generatedStudentId,
              $name,
              $email,
              $hash
            ]);

            $success = "Registration successful! You can now login.";

          } 
      } catch (PDOException $e) {
            $error = "Could not register. Please try again.";
          }
    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Registration</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
  <div class="container" style="max-width:560px;margin-top:40px;">
    <div class="card">
      <h2 style="margin-top:0;">Student Registration</h2>
      <p class="muted" style="margin-top:6px;">Create your student account to book rooms.</p>

      <?php if ($error): ?>
        <div class="alert"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <?php if ($success): ?>
        <div class="alert" style="border-color:rgba(16,185,129,.35);background:rgba(16,185,129,.12);">
          <?= htmlspecialchars($success) ?>
        </div>
      <?php endif; ?>

      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div class="form-row">
          <label>Full Name</label>
          <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>
        </div>

        <div class="form-row">
          <label>Email</label>
          <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>
        </div>

        <div class="form-row">
          <label>Password</label>
          <input type="password" name="password" required>
          <p class="muted" style="margin:6px 0 0 0;">Minimum 5 characters.</p>
        </div>

        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px;">
          <button class="btn" type="submit">Register</button>
          <a class="btn secondary" href="../public/student_login.php">Back to Student Login</a>
          <a class="btn secondary" href="../public/landing.php">Home</a>
        </div>
      </form>
    </div>
  </div>
</body>
</html>