<?php
// public/students.php
// Purpose: List all students (occupants) and provide links to add/edit/delete

$pageTitle = "Students";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';

// Fetch all students
$stmt = $pdo->query("SELECT * FROM students ORDER BY created_at DESC");
$students = $stmt->fetchAll();
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
      <div>
        <h2 style="margin:0;">Students</h2>
        <p class="muted" style="margin:6px 0 0 0;">Manage student/occupant records.</p>
      </div>
      <a class="btn" href="student_add.php">+ Add Student</a>
    </div>

    <div class="card">
      <?php if (empty($students)): ?>
        <p class="muted">No students found. Click “Add Student” to create your first record.</p>
      <?php else: ?>
        <div style="overflow:auto;">
          <table style="width:100%;border-collapse:collapse;">
            <thead>
              <tr>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Student ID</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Name</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Email</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Phone</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Status</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($students as $s): ?>
                <tr>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($s['student_id']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($s['name']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($s['email']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($s['phone']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($s['status']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <a class="btn secondary" href="student_edit.php?id=<?= (int)$s['id'] ?>">Edit</a>
                    <a class="btn secondary" href="student_delete.php?id=<?= (int)$s['id'] ?>">Delete</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>