<?php
// public/payments.php
// Purpose: List payments and show status (paid/due/overdue). Also auto-marks overdue based on due_date.

$pageTitle = "Payments";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';

// --- Auto-mark overdue payments (smart feature) ---
// If status is 'due' and due_date < today and paid_date is NULL => set to 'overdue'
$pdo->prepare("
  UPDATE payments
  SET status='overdue'
  WHERE status='due'
    AND paid_date IS NULL
    AND due_date < CURDATE()
")->execute();

// Optional filter
$filter = $_GET['status'] ?? '';
$allowed = ['paid','due','overdue'];

$where = "";
$params = [];

if (in_array($filter, $allowed, true)) {
  $where = "WHERE p.status = ?";
  $params[] = $filter;
}

// Fetch payments with student info
$sql = "
  SELECT p.*, s.student_id AS sid, s.name AS student_name
  FROM payments p
  JOIN students s ON s.id = p.student_id
  $where
  ORDER BY p.created_at DESC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$payments = $stmt->fetchAll();
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
      <div>
        <h2 style="margin:0;">Payments</h2>
        <p class="muted" style="margin:6px 0 0 0;">Record rent/fees and track paid/due/overdue.</p>
      </div>
      <a class="btn" href="payment_add.php">+ Add Payment</a>
    </div>

    <div class="card" style="margin-bottom:12px;">
      <strong>Filter:</strong>
      <a class="btn secondary" href="payments.php" style="margin-left:8px;">All</a>
      <a class="btn secondary" href="payments.php?status=paid">Paid</a>
      <a class="btn secondary" href="payments.php?status=due">Due</a>
      <a class="btn secondary" href="payments.php?status=overdue">Overdue</a>
    </div>

    <div class="card">
      <?php if (empty($payments)): ?>
        <p class="muted">No payments found. Click “Add Payment” to create one.</p>
      <?php else: ?>
        <div style="overflow:auto;">
          <table style="width:100%;border-collapse:collapse;">
            <thead>
              <tr>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Student</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Month</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Amount</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Due Date</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Paid Date</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Status</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($payments as $p): ?>
                <tr>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <?= htmlspecialchars($p['student_name']) ?> (<?= htmlspecialchars($p['sid']) ?>)
                  </td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($p['pay_month']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= number_format((float)$p['amount'], 2) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($p['due_date']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($p['paid_date'] ?? '-') ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($p['status']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <a class="btn secondary" href="payment_edit.php?id=<?= (int)$p['id'] ?>">Edit</a>
                    <a class="btn secondary" href="payment_delete.php?id=<?= (int)$p['id'] ?>">Delete</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>