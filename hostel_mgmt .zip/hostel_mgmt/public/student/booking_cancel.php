<?php
// public/student/booking_cancel.php
// Purpose: Student cancels ONLY their own booking.

require_once __DIR__ . '/../../includes/student_auth.php';
require_student_login();

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/csrf.php';

$studentDbId = (int)($_SESSION['student_db_id'] ?? 0);
$error = '';
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) die("Invalid booking ID.");

// Fetch booking only if it belongs to this student
$stmt = $pdo->prepare("
  SELECT b.*, r.room_no, r.room_type
  FROM bookings b
  JOIN rooms r ON r.id = b.room_id
  WHERE b.id = ? AND b.student_id = ?
");
$stmt->execute([$id, $studentDbId]);
$bk = $stmt->fetch();

if (!$bk) {
  die("Booking not found or you do not have permission.");
}

if ($bk['status'] !== 'booked') {
  die("Only booked bookings can be cancelled.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $upd = $pdo->prepare("UPDATE bookings SET status='cancelled' WHERE id=? AND student_id=?");
    $upd->execute([$id, $studentDbId]);

    header("Location: /hostel_mgmt/public/student/bookings.php");
    exit;
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Cancel Booking</title>
  <link rel="stylesheet" href="/hostel_mgmt/assets/css/style.css">
</head>
<body>
  <div class="container" style="margin-top:20px;max-width:780px;">
    <div class="card">
      <h2 style="margin-top:0;">Cancel Booking</h2>
      <p class="muted">Room: <?= htmlspecialchars($bk['room_no']) ?> - <?= htmlspecialchars($bk['room_type']) ?></p>
      <p class="muted">Dates: <?= htmlspecialchars($bk['start_date']) ?> → <?= htmlspecialchars($bk['end_date']) ?></p>

      <?php if ($error): ?>
        <div class="alert"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
        <button class="btn" type="submit">Yes, Cancel</button>
        <a class="btn secondary" href="/hostel_mgmt/public/student/bookings.php">Back</a>
      </form>
    </div>
  </div>
</body>
</html>