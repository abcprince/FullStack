<?php
// public/student/booking_add.php
// Purpose: Student books a room for a date range (student is auto-selected).

require_once __DIR__ . '/../../includes/student_auth.php';
require_student_login();

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/csrf.php';

$error = '';
$studentDbId = (int)($_SESSION['student_db_id'] ?? 0);

// Room types for filter
$roomTypes = $pdo->query("SELECT DISTINCT room_type FROM rooms ORDER BY room_type ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $room_id    = (int)($_POST['room_id'] ?? 0);
    $start_date = $_POST['start_date'] ?? '';
    $end_date   = $_POST['end_date'] ?? '';

    if ($room_id <= 0 || $start_date === '' || $end_date === '') {
      $error = "Room, start date, and end date are required.";
    } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
      $error = "Invalid date format.";
    } elseif (strtotime($end_date) < strtotime($start_date)) {
      $error = "End date cannot be before start date.";
    } else {
      // Block overlap bookings for the same room
      $conf = $pdo->prepare("
        SELECT COUNT(*) AS c
        FROM bookings
        WHERE room_id = ?
          AND status IN ('booked','checked_in')
          AND start_date <= ?
          AND end_date >= ?
      ");
      $conf->execute([$room_id, $end_date, $start_date]);

      if ((int)($conf->fetch()['c'] ?? 0) > 0) {
        $error = "That room is already booked in the selected date range.";
      } else {
        $ins = $pdo->prepare("
          INSERT INTO bookings (student_id, room_id, start_date, end_date, status)
          VALUES (?, ?, ?, ?, 'booked')
        ");
        $ins->execute([$studentDbId, $room_id, $start_date, $end_date]);

        header("Location: ../../public/student/bookings.php");
        exit;
      }
    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>New Booking</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
  <div class="container" style="margin-top:20px;max-width:900px;">
    <div class="card" style="display:flex;justify-content:space-between;align-items:center;">
      <div>
        <h2 style="margin:0;">Create Booking</h2>
        <p class="muted" style="margin:6px 0 0 0;">Pick dates first — available rooms load automatically (Ajax).</p>
      </div>
      <div style="display:flex;gap:10px;">
        <a class="btn secondary" href="../../public/student/bookings.php">Back</a>
        <a class="btn secondary" href="../../public/student_logout.php">Logout</a>
      </div>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-top:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="margin-top:12px;">
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          <div class="form-row">
            <label>Start Date</label>
            <input id="startDate" type="date" name="start_date" required>
          </div>
          <div class="form-row">
            <label>End Date</label>
            <input id="endDate" type="date" name="end_date" required>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          <div class="form-row">
            <label>Room Type (filter)</label>
            <select id="roomTypeFilter">
              <option value="">All Types</option>
              <?php foreach ($roomTypes as $t): ?>
                <option value="<?= htmlspecialchars($t['room_type']) ?>"><?= htmlspecialchars($t['room_type']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-row">
            <label>Available Rooms</label>
            <select id="roomSelect" name="room_id" required>
              <option value="">Select dates first...</option>
            </select>
          </div>
        </div>

        <button class="btn" type="submit">Book Now</button>
      </form>
    </div>
  </div>

<script>
// Ajax: Load available rooms for selected dates
const startEl = document.getElementById('startDate');
const endEl   = document.getElementById('endDate');
const typeEl  = document.getElementById('roomTypeFilter');
const roomEl  = document.getElementById('roomSelect');

async function loadRooms() {
  const start = startEl.value;
  const end = endEl.value;
  const type = typeEl.value;

  roomEl.innerHTML = `<option value="">Loading...</option>`;

  if (!start || !end) {
    roomEl.innerHTML = `<option value="">Select dates first...</option>`;
    return;
  }

  const params = new URLSearchParams();
  params.append('start_date', start);
  params.append('end_date', end);
  if (type) params.append('room_type', type);

  try {
    const res = await fetch('../../public/ajax_available_rooms.php?' + params.toString());
    const data = await res.json();

    if (!data.ok || !Array.isArray(data.rooms)) {
      roomEl.innerHTML = `<option value="">Error loading rooms</option>`;
      return;
    }

    if (data.rooms.length === 0) {
      roomEl.innerHTML = `<option value="">No rooms available for these dates</option>`;
      return;
    }

    roomEl.innerHTML = `<option value="">-- Select Room --</option>`;
    for (const r of data.rooms) {
      const opt = document.createElement('option');
      opt.value = r.id;
      opt.textContent = `${r.room_no} - ${r.room_type} (beds avail: ${r.beds_available})`;
      roomEl.appendChild(opt);
    }
  } catch (e) {
    roomEl.innerHTML = `<option value="">Error loading rooms</option>`;
  }
}

startEl.addEventListener('change', loadRooms);
endEl.addEventListener('change', loadRooms);
typeEl.addEventListener('change', loadRooms);
</script>
</body>
</html>