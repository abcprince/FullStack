<?php
// public/student/dashboard.php
// Purpose: Student dashboard (view own info + quick links)

require_once __DIR__ . '/../../includes/student_auth.php';
require_student_login();

require_once __DIR__ . '/../../config/db.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Dashboard</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
  <div class="container" style="margin-top:20px;">
    <div class="card" style="display:flex;justify-content:space-between;align-items:center;">
      <div>
        <h2 style="margin:0;">Welcome, <?= htmlspecialchars($_SESSION['student_name']) ?> 👋</h2>
        <p class="muted" style="margin:6px 0 0 0;">Student portal (Bookings only).</p>
      </div>
      <a class="btn secondary" href="../public/student_logout.php">Logout</a>
    </div>

    <div class="card" style="margin-top:12px;">
      <h3 style="margin-top:0;">What you can do</h3>
    <ul style="margin-bottom:14px;">
    <li>
        <a href="bookings.php">View your bookings</a>
    </li>
    <li>
        <a href="booking_add.php">Create a new booking</a>
    </li>
    <li>
        <a href="bookings.php">Cancel your booking</a>
        <span class="muted"> (open a booking and click Cancel)</span>
    </li>
    </ul>

    <div style="display:flex;gap:10px;flex-wrap:wrap;">
    <a class="btn" href="bookings.php">My Bookings</a>
    <a class="btn secondary" href="booking_add.php">New Booking</a>
    </div>

    </div>
  </div>
</body>
</html>