<?php
// public/student/bookings.php
// Purpose: Student can view ONLY their own bookings.

require_once __DIR__ . '/../../includes/student_auth.php';
require_student_login();

require_once __DIR__ . '/../../config/db.php';

$studentDbId = (int)($_SESSION['student_db_id'] ?? 0);

$stmt = $pdo->prepare("
  SELECT b.*, r.room_no, r.room_type
  FROM bookings b
  JOIN rooms r ON r.id = b.room_id
  WHERE b.student_id = ?
  ORDER BY b.created_at DESC
");
$stmt->execute([$studentDbId]);
$bookings = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
  <title>My Bookings</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
  <div class="container" style="margin-top:20px;">
    <div class="card" style="display:flex;justify-content:space-between;align-items:center;">
      <div>
        <h2 style="margin:0;">My Bookings</h2>
        <p class="muted" style="margin:6px 0 0 0;">Only your bookings are shown here.</p>
      </div>
      <div style="display:flex;gap:10px;">
        <a class="btn secondary" href="../../public/student/dashboard.php">Dashboard</a>
        <a class="btn" href="../../public/student/booking_add.php">+ New Booking</a>
        <a class="btn secondary" href="../../public/student_logout.php">Logout</a>
      </div>
    </div>

    <div class="card" style="margin-top:12px;">
      <?php if (empty($bookings)): ?>
        <p class="muted">You don’t have any bookings yet.</p>
        <a class="btn" href="../../public/student/booking_add.php">Create your first booking</a>
      <?php else: ?>
        <div style="overflow:auto;">
          <table style="width:100%;border-collapse:collapse;">
            <thead>
              <tr>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Room</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Start</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">End</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Status</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($bookings as $b): ?>
                <tr>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <?= htmlspecialchars($b['room_no']) ?> - <?= htmlspecialchars($b['room_type']) ?>
                  </td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($b['start_date']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($b['end_date']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($b['status']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <?php if ($b['status'] === 'booked'): ?>
                      <a class="btn secondary" href="../../public/student/booking_cancel.php?id=<?= (int)$b['id'] ?>">Cancel</a>
                    <?php else: ?>
                      <span class="muted">—</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>