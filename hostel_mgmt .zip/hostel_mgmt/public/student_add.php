<?php
// public/student_add.php
// Purpose: Add a new student (occupant) securely using CSRF + validation + prepared statements

$pageTitle = "Add Student";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // 1) CSRF protection
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    // 2) Read & validate inputs
    $student_id     = trim($_POST['student_id'] ?? '');
    $name           = trim($_POST['name'] ?? '');
    $email          = trim($_POST['email'] ?? '');
    $phone          = trim($_POST['phone'] ?? '');
    $guardian_phone = trim($_POST['guardian_phone'] ?? '');
    $address        = trim($_POST['address'] ?? '');
    $status         = $_POST['status'] ?? 'active';

    if ($student_id === '' || $name === '' || $email === '' || $phone === '') {
      $error = "Student ID, name, email, and phone are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $error = "Enter a valid email.";
    } elseif (!in_array($status, ['active','inactive'], true)) {
      $error = "Invalid status selected.";
    } else {
      // 3) Insert with prepared statement
      $sql = "INSERT INTO students (student_id, name, email, phone, guardian_phone, address, status)
              VALUES (?, ?, ?, ?, ?, ?, ?)";
      $stmt = $pdo->prepare($sql);

      try {
        $stmt->execute([$student_id, $name, $email, $phone, $guardian_phone ?: null, $address ?: null, $status]);
        header("Location: students.php");
        exit;
      } catch (PDOException $e) {
        // Likely duplicate student_id or email
        $error = "Could not add student. Student ID or email may already exist.";
      }
    }
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Add Student</h2>
      <p class="muted" style="margin:6px 0 0 0;">Create a new student/occupant record.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:700px;">
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div class="form-row">
          <label>Student ID</label>
          <input type="text" name="student_id" placeholder="e.g. 2513257" required>
        </div>

        <div class="form-row">
          <label>Full Name</label>
          <input type="text" name="name" required>
        </div>

        <div class="form-row">
          <label>Email</label>
          <input type="email" name="email" required>
        </div>

        <div class="form-row">
          <label>Phone</label>
          <input type="text" name="phone" required>
        </div>

        <div class="form-row">
          <label>Guardian Phone (optional)</label>
          <input type="text" name="guardian_phone">
        </div>

        <div class="form-row">
          <label>Address (optional)</label>
          <input type="text" name="address">
        </div>

        <div class="form-row">
          <label>Status</label>
          <select name="status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>

        <button class="btn" type="submit">Save Student</button>
        <a class="btn secondary" href="students.php">Cancel</a>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>