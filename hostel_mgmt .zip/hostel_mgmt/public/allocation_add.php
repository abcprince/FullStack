<?php
// public/allocation_add.php
// Purpose: Assign a student to a room/bed (check-in) with validation

$pageTitle = "New Check-in";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';

// Fetch active students
$students = $pdo->query("SELECT id, student_id, name FROM students WHERE status='active' ORDER BY name ASC")->fetchAll();

// Fetch rooms that are not in maintenance
$rooms = $pdo->query("SELECT id, room_no, room_type, capacity FROM rooms WHERE status='available' ORDER BY room_no ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $room_id    = (int)($_POST['room_id'] ?? 0);
    $bed_no     = (int)($_POST['bed_no'] ?? 0);
    $checkin    = $_POST['checkin_date'] ?? '';
    $expected   = $_POST['expected_checkout_date'] ?? '';

    if ($student_id <= 0 || $room_id <= 0 || $bed_no <= 0 || $checkin === '') {
      $error = "Student, room, bed number, and check-in date are required.";
    } else {
      // 1) Check student doesn't already have an active allocation
      $stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM allocations WHERE student_id=? AND allocation_status='active'");
      $stmt->execute([$student_id]);
      if ((int)($stmt->fetch()['c'] ?? 0) > 0) {
        $error = "This student already has an active allocation.";
      } else {
        // 2) Validate bed_no is within room capacity
        $capStmt = $pdo->prepare("SELECT capacity FROM rooms WHERE id=? AND status='available'");
        $capStmt->execute([$room_id]);
        $roomRow = $capStmt->fetch();

        if (!$roomRow) {
          $error = "Selected room is not available.";
        } elseif ($bed_no < 1 || $bed_no > (int)$roomRow['capacity']) {
          $error = "Bed number must be between 1 and " . (int)$roomRow['capacity'] . ".";
        } else {
          // 3) Check bed is not already occupied (active allocation)
          $bedStmt = $pdo->prepare("SELECT COUNT(*) AS c FROM allocations WHERE room_id=? AND bed_no=? AND allocation_status='active'");
          $bedStmt->execute([$room_id, $bed_no]);

          if ((int)($bedStmt->fetch()['c'] ?? 0) > 0) {
            $error = "That bed is already occupied. Choose another bed.";
          } else {
            // 4) Insert allocation
            $sql = "INSERT INTO allocations (student_id, room_id, bed_no, checkin_date, expected_checkout_date, allocation_status)
                    VALUES (?, ?, ?, ?, ?, 'active')";
            $ins = $pdo->prepare($sql);

            try {
              $ins->execute([$student_id, $room_id, $bed_no, $checkin, ($expected !== '' ? $expected : null)]);
              header("Location: allocations.php");
              exit;
            } catch (PDOException $e) {
              $error = "Could not create allocation. Please try again.";
            }
          }
        }
      }
    }
  }
}

?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">New Check-in</h2>
      <p class="muted" style="margin:6px 0 0 0;">Assign a student to a room and bed.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:750px;">
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div class="form-row">
          <label>Student</label>
          <select name="student_id" required>
            <option value="">-- Select Student --</option>
            <?php foreach ($students as $s): ?>
              <option value="<?= (int)$s['id'] ?>">
                <?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['student_id']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-row">
          <label>Room</label>
          <select name="room_id" required>
            <option value="">-- Select Room --</option>
            <?php foreach ($rooms as $r): ?>
              <option value="<?= (int)$r['id'] ?>">
                <?= htmlspecialchars($r['room_no']) ?> - <?= htmlspecialchars($r['room_type']) ?> (capacity <?= (int)$r['capacity'] ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-row">
          <label>Bed Number</label>
          <input type="number" name="bed_no" min="1" required placeholder="1, 2, 3 ...">
          <p class="muted" style="margin:6px 0 0 0;">Must be within the selected room's capacity.</p>
        </div>

        <div class="form-row">
          <label>Check-in Date</label>
          <input type="date" name="checkin_date" required>
        </div>

        <div class="form-row">
          <label>Expected Checkout Date (optional)</label>
          <input type="date" name="expected_checkout_date">
        </div>

        <button class="btn" type="submit">Create Allocation</button>
        <a class="btn secondary" href="allocations.php">Cancel</a>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>