<?php
// public/logout.php
// Purpose: Log out safely by destroying the session

require_once __DIR__ . '/../config/session.php';

// Clear session data
$_SESSION = [];

// Destroy session cookie (best practice)
if (ini_get("session.use_cookies")) {
  $params = session_get_cookie_params();
  setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
}

// Destroy session
session_destroy();

// Redirect to login page
header("Location: login.php");
exit;