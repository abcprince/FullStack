<?php
// public/payment_delete.php
// Purpose: Confirm and delete a payment record securely (CSRF)

$pageTitle = "Delete Payment";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) die("Invalid payment ID.");

$stmt = $pdo->prepare("
  SELECT p.*, s.name AS student_name, s.student_id AS sid
  FROM payments p
  JOIN students s ON s.id = p.student_id
  WHERE p.id = ?
");
$stmt->execute([$id]);
$pay = $stmt->fetch();

if (!$pay) die("Payment not found.");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $del = $pdo->prepare("DELETE FROM payments WHERE id=?");
    $del->execute([$id]);
    header("Location: payments.php");
    exit;
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Delete Payment</h2>
      <p class="muted" style="margin:6px 0 0 0;">This action cannot be undone.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:750px;">
      <p>Delete payment for:</p>
      <p><strong><?= htmlspecialchars($pay['student_name']) ?></strong> (<?= htmlspecialchars($pay['sid']) ?>)</p>
      <p class="muted">Month: <?= htmlspecialchars($pay['pay_month']) ?> | Amount: <?= number_format((float)$pay['amount'],2) ?> | Status: <?= htmlspecialchars($pay['status']) ?></p>

      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
        <button class="btn" type="submit">Yes, Delete</button>
        <a class="btn secondary" href="payments.php">Cancel</a>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>