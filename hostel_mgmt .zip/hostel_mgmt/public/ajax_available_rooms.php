<?php
// public/ajax_available_rooms.php
// Purpose: Return available rooms (JSON) based on filters.
// Supports date range overlap checks for bookings (booking calendar).

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// Allow admin/staff OR student sessions
$isAdminOrStaff = !empty($_SESSION['user_id']); // your admin login sets this
$isStudent      = (($_SESSION['user_type'] ?? '') === 'student' && !empty($_SESSION['student_db_id']));

if (!$isAdminOrStaff && !$isStudent) {
  http_response_code(401);
  header('Content-Type: application/json');
  echo json_encode(['ok' => false, 'error' => 'Unauthorized']);
  exit;
}

require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

// ---- rest of your existing SQL logic below (keep it same) ----

require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$roomType = trim($_GET['room_type'] ?? '');
$minCap   = (int)($_GET['min_capacity'] ?? 0);
$start    = $_GET['start_date'] ?? '';  // optional (YYYY-MM-DD)
$end      = $_GET['end_date'] ?? '';    // optional (YYYY-MM-DD)

if ($minCap < 0) $minCap = 0;

// Basic date validation (only if provided)
$useDates = false;
if ($start !== '' && $end !== '') {
  $useDates = preg_match('/^\d{4}-\d{2}-\d{2}$/', $start) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $end);
}

$params = [];

/*
Availability definition:
- Room must be in status 'available'
- Must have at least 1 bed free NOW based on allocations (active)
- If date range provided: must NOT have an overlapping booking in status 'booked' or 'checked_in'

Overlap rule:
Existing booking overlaps if: (start_date <= requested_end) AND (end_date >= requested_start)
*/
$sql = "
  SELECT
    r.id,
    r.room_no,
    r.room_type,
    r.capacity,
    r.price,
    (r.capacity - COALESCE(a.active_count, 0)) AS beds_available
  FROM rooms r
  LEFT JOIN (
    SELECT room_id, COUNT(*) AS active_count
    FROM allocations
    WHERE allocation_status='active'
    GROUP BY room_id
  ) a ON a.room_id = r.id
  WHERE r.status='available'
    AND (r.capacity - COALESCE(a.active_count,0)) > 0
";

// Filters
if ($roomType !== '') {
  $sql .= " AND r.room_type = ? ";
  $params[] = $roomType;
}
if ($minCap > 0) {
  $sql .= " AND r.capacity >= ? ";
  $params[] = $minCap;
}

// Date-range filter (exclude rooms with overlapping bookings)
if ($useDates) {
  $sql .= "
    AND r.id NOT IN (
      SELECT b.room_id
      FROM bookings b
      WHERE b.status IN ('booked','checked_in')
        AND b.start_date <= ?
        AND b.end_date >= ?
    )
  ";
  // Note order: end then start (matches overlap formula)
  $params[] = $end;
  $params[] = $start;
}

$sql .= " ORDER BY r.room_no ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

echo json_encode([
  'ok' => true,
  'count' => $stmt->rowCount(),
  'rooms' => $stmt->fetchAll(),
  'date_filter_used' => $useDates
]);