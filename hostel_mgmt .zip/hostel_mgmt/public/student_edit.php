<?php
// public/student_edit.php
// Purpose: Edit an existing student using a pre-filled form + safe update

$pageTitle = "Edit Student";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
  die("Invalid student ID.");
}

// Fetch student
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) {
  die("Student not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    // Existing fields
    $student_id     = trim($_POST['student_id'] ?? '');
    $name           = trim($_POST['name'] ?? '');
    $email          = trim($_POST['email'] ?? '');
    $phone          = trim($_POST['phone'] ?? '');
    $guardian_phone = trim($_POST['guardian_phone'] ?? '');
    $address        = trim($_POST['address'] ?? '');
    $status         = $_POST['status'] ?? 'active';

    // NEW fields for student login
    $can_login    = (int)($_POST['can_login'] ?? 0);
    $new_password = trim($_POST['new_password'] ?? '');
    if ($can_login !== 1) {
      $can_login = 0;
    }

    // Basic validation
    if ($student_id === '' || $name === '' || $email === '' || $phone === '') {
      $error = "Student ID, name, email, and phone are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $error = "Enter a valid email.";
    } elseif (!in_array($status, ['active','inactive'], true)) {
      $error = "Invalid status selected.";
    } else {


    // Existing fields
    $student_id     = trim($_POST['student_id'] ?? '');

      // NEW: only hash password if admin entered one
      $password_hash = null;
      if ($new_password !== '') {
        $password_hash = password_hash($new_password, PASSWORD_BCRYPT);
      }

      // NEW: update can_login + (optional) password_hash
      // COALESCE keeps old password_hash if $password_hash is NULL
      $sql = "UPDATE students
              SET student_id=?,
                  name=?,
                  email=?,
                  phone=?,
                  guardian_phone=?,
                  address=?,
                  status=?,
                  can_login=?,
                  password_hash = COALESCE(?, password_hash)
              WHERE id=?";
      $upd = $pdo->prepare($sql);

      try {
        $upd->execute([
          $student_id,
          $name,
          $email,
          $phone,
          $guardian_phone ?: null,
          $address ?: null,
          $status,
          $can_login,
          $password_hash, // null -> keeps old password_hash
          $id
        ]);

        header("Location: students.php");
        exit;
      } catch (PDOException $e) {
        $error = "Could not update student. Student ID or email may already exist.";
      }
    }
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Edit Student</h2>
      <p class="muted" style="margin:6px 0 0 0;">Update student details.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:700px;">
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div class="form-row">
          <label>Student ID</label>
          <input type="text" name="student_id" value="<?= htmlspecialchars($student['student_id']) ?>" required>
        </div>

        <div class="form-row">
          <label>Full Name</label>
          <input type="text" name="name" value="<?= htmlspecialchars($student['name']) ?>" required>
        </div>

        <div class="form-row">
          <label>Email</label>
          <input type="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" required>
        </div>

        <div class="form-row">
          <label>Phone</label>
          <input type="text" name="phone" value="<?= htmlspecialchars($student['phone']) ?>" required>
        </div>

        <div class="form-row">
          <label>Guardian Phone (optional)</label>
          <input type="text" name="guardian_phone" value="<?= htmlspecialchars($student['guardian_phone'] ?? '') ?>">
        </div>

        <div class="form-row">
          <label>Address (optional)</label>
          <input type="text" name="address" value="<?= htmlspecialchars($student['address'] ?? '') ?>">
        </div>

        <div class="form-row">
          <label>Status</label>
          <select name="status">
            <option value="active" <?= $student['status']==='active'?'selected':'' ?>>Active</option>
            <option value="inactive" <?= $student['status']==='inactive'?'selected':'' ?>>Inactive</option>
          </select>
        </div>

        <div class="form-row">
          <label>Enable Student Login</label>
          <select name="can_login">
            <option value="0" <?= ((int)($student['can_login'] ?? 0) === 0) ? 'selected' : '' ?>>No</option>
            <option value="1" <?= ((int)($student['can_login'] ?? 0) === 1) ? 'selected' : '' ?>>Yes</option>
          </select>
        </div>

        <div class="form-row">
          <label>Set / Reset Student Password (optional)</label>
          <input type="password" name="new_password" placeholder="Leave empty to keep current password">
          <p class="muted" style="margin:6px 0 0 0;">If you enter a password here, it will replace the old one.</p>
        </div>

        <button class="btn" type="submit">Update Student</button>
        <a class="btn secondary" href="students.php">Cancel</a>


      </form>
    </div>
  </div>
</div>



<?php require_once __DIR__ . '/../includes/footer.php'; ?>