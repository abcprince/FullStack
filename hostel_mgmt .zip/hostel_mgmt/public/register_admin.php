<?php
// public/register_admin.php
// Purpose: Create the FIRST admin account (disable/lock later if you want)

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';

$pageTitle = "Register Admin";

$success = '';
$error = '';

// Optional: Block this page if an admin already exists (recommended)
$stmt = $pdo->query("SELECT COUNT(*) AS c FROM admins");
$countRow = $stmt->fetch();
$adminExists = ($countRow && (int)$countRow['c'] > 0);

if ($adminExists) {
  // If you want to allow creating more admins later, do it from an admin-only page instead.
  $error = "Admin already exists. Please login.";
} else {
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1) CSRF check
    if (!csrf_validate($_POST['csrf_token'] ?? null)) {
      $error = "Security check failed. Please refresh and try again.";
    } else {
      // 2) Collect + basic validation
      $name  = trim($_POST['name'] ?? '');
      $email = trim($_POST['email'] ?? '');
      $pass  = $_POST['password'] ?? '';

      if ($name === '' || $email === '' || $pass === '') {
        $error = "All fields are required.";
      } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Enter a valid email.";
      } elseif (strlen($pass) < 6) {
        $error = "Password must be at least 6 characters.";
      } else {
        // 3) Hash password securely
        $hash = password_hash($pass, PASSWORD_BCRYPT);

        // 4) Insert admin using prepared statement
        $sql = "INSERT INTO admins (name, email, password_hash, role) VALUES (?, ?, ?, 'admin')";
        $stmt = $pdo->prepare($sql);

        try {
          $stmt->execute([$name, $email, $hash]);
          $success = "Admin created successfully. You can now login.";
        } catch (PDOException $e) {
          // Generic message (avoid leaking details)
          $error = "Could not create admin. Try a different email.";
        }
      }
    }
  }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card" style="max-width:520px;margin:0 auto;">
  <h2>Create First Admin</h2>

  <?php if ($success): ?>
    <div class="card" style="border-color:#bbf7d0;background:#f0fdf4;margin-bottom:12px;">
      <?= htmlspecialchars($success) ?>
      <div style="margin-top:10px;">
        <a class="btn" href="login.php">Go to Login</a>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($error): ?>
    <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if (!$adminExists): ?>
    <form method="POST" action="">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

      <div class="form-row">
        <label>Full Name</label>
        <input type="text" name="name" required>
      </div>

      <div class="form-row">
        <label>Email</label>
        <input type="email" name="email" required>
      </div>

      <div class="form-row">
        <label>Password</label>
        <input type="password" name="password" required>
      </div>

      <button class="btn" type="submit">Create Admin</button>
      <a class="btn secondary" href="login.php">Back to Login</a>
    </form>
  <?php else: ?>
    <a class="btn" href="login.php">Go to Login</a>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>