<?php
// public/student_delete.php
// Purpose: Confirm and delete a student (block if active allocation exists)

$pageTitle = "Delete Student";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
  die("Invalid student ID.");
}

// Fetch student
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) {
  die("Student not found.");
}

// Check active allocation
$check = $pdo->prepare("SELECT COUNT(*) AS c FROM allocations WHERE student_id=? AND allocation_status='active'");
$check->execute([$id]);
$activeAlloc = (int)($check->fetch()['c'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } elseif ($activeAlloc > 0) {
    $error = "Cannot delete this student because they have an active allocation.";
  } else {
    $del = $pdo->prepare("DELETE FROM students WHERE id = ?");
    $del->execute([$id]);
    header("Location: students.php");
    exit;
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Delete Student</h2>
      <p class="muted" style="margin:6px 0 0 0;">This action cannot be undone.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:700px;">
      <p>Are you sure you want to delete:</p>
      <p><strong><?= htmlspecialchars($student['name']) ?></strong> (<?= htmlspecialchars($student['student_id']) ?>)</p>

      <?php if ($activeAlloc > 0): ?>
        <div class="alert" style="margin-top:12px;">
          This student has <strong><?= $activeAlloc ?></strong> active allocation(s). Checkout first.
        </div>
        <div style="margin-top:12px;">
          <a class="btn secondary" href="students.php">Back</a>
        </div>
      <?php else: ?>
        <form method="POST" action="">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
          <button class="btn" type="submit">Yes, Delete</button>
          <a class="btn secondary" href="students.php">Cancel</a>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>