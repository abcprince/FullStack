<?php
// public/room_edit.php
// Purpose: Edit an existing room (pre-filled form + POST update)

$pageTitle = "Edit Room";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
  die("Invalid room ID.");
}

// Fetch the room
$stmt = $pdo->prepare("SELECT * FROM rooms WHERE id = ?");
$stmt->execute([$id]);
$room = $stmt->fetch();

if (!$room) {
  die("Room not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $room_no   = trim($_POST['room_no'] ?? '');
    $room_type = trim($_POST['room_type'] ?? '');
    $capacity  = (int)($_POST['capacity'] ?? 0);
    $price     = (float)($_POST['price'] ?? 0);
    $status    = $_POST['status'] ?? 'available';

    if ($room_no === '' || $room_type === '') {
      $error = "Room number and room type are required.";
    } elseif ($capacity <= 0) {
      $error = "Capacity must be greater than 0.";
    } elseif (!in_array($status, ['available', 'maintenance'], true)) {
      $error = "Invalid status selected.";
    } else {
      $sql = "UPDATE rooms SET room_no=?, room_type=?, capacity=?, price=?, status=? WHERE id=?";
      $update = $pdo->prepare($sql);

      try {
        $update->execute([$room_no, $room_type, $capacity, $price, $status, $id]);
        header("Location: rooms.php");
        exit;
      } catch (PDOException $e) {
        $error = "Could not update room. Room number may already exist.";
      }
    }
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Edit Room</h2>
      <p class="muted" style="margin:6px 0 0 0;">Update room details.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:650px;">
      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

        <div class="form-row">
          <label>Room Number</label>
          <input type="text" name="room_no" value="<?= htmlspecialchars($room['room_no']) ?>" required>
        </div>

        <div class="form-row">
          <label>Room Type</label>
          <input type="text" name="room_type" value="<?= htmlspecialchars($room['room_type']) ?>" required>
        </div>

        <div class="form-row">
          <label>Capacity (beds)</label>
          <input type="number" name="capacity" min="1" value="<?= (int)$room['capacity'] ?>" required>
        </div>

        <div class="form-row">
          <label>Price (monthly)</label>
          <input type="number" name="price" step="0.01" min="0" value="<?= htmlspecialchars($room['price']) ?>">
        </div>

        <div class="form-row">
          <label>Status</label>
          <select name="status">
            <option value="available" <?= $room['status']==='available'?'selected':'' ?>>Available</option>
            <option value="maintenance" <?= $room['status']==='maintenance'?'selected':'' ?>>Maintenance</option>
          </select>
        </div>

        <button class="btn" type="submit">Update Room</button>
        <a class="btn secondary" href="rooms.php">Cancel</a>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>