<?php
// public/bookings.php
// Purpose: Show a booking calendar (month view) + list of bookings for that month.

$pageTitle = "Bookings";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';

// Choose month (YYYY-MM)
$month = $_GET['month'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $month)) $month = date('Y-m');

$firstDay = $month . '-01';
$daysInMonth = (int)date('t', strtotime($firstDay));
$startWeekday = (int)date('N', strtotime($firstDay)); // 1=Mon ... 7=Sun

$monthStart = $firstDay;
$monthEnd = date('Y-m-t', strtotime($firstDay));

// Fetch bookings overlapping this month (booked/checked_in/cancelled included for display)
$stmt = $pdo->prepare("
  SELECT b.*, s.name AS student_name, s.student_id AS sid, r.room_no, r.room_type
  FROM bookings b
  JOIN students s ON s.id = b.student_id
  JOIN rooms r ON r.id = b.room_id
  WHERE b.start_date <= ? AND b.end_date >= ?
  ORDER BY b.start_date ASC
");
$stmt->execute([$monthEnd, $monthStart]);
$bookings = $stmt->fetchAll();

// Build a day => count map for calendar highlighting
$dayCounts = array_fill(1, $daysInMonth, 0);
foreach ($bookings as $b) {
  // Clamp range to current month
  $s = max($monthStart, $b['start_date']);
  $e = min($monthEnd, $b['end_date']);
  $cur = strtotime($s);
  $end = strtotime($e);
  while ($cur <= $end) {
    $d = (int)date('j', $cur);
    if ($d >= 1 && $d <= $daysInMonth && $b['status'] !== 'cancelled') {
      $dayCounts[$d] += 1;
    }
    $cur = strtotime('+1 day', $cur);
  }
}

// Month navigation
$prevMonth = date('Y-m', strtotime($firstDay . ' -1 month'));
$nextMonth = date('Y-m', strtotime($firstDay . ' +1 month'));
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
      <div>
        <h2 style="margin:0;">Booking Calendar</h2>
        <p class="muted" style="margin:6px 0 0 0;">Monthly view + bookings list.</p>
      </div>
      <a class="btn" href="booking_add.php">+ New Booking</a>
    </div>

    <div class="card" style="display:flex;gap:10px;align-items:center;justify-content:space-between;margin-bottom:12px;">
      <a class="btn secondary" href="bookings.php?month=<?= htmlspecialchars($prevMonth) ?>">← Prev</a>
      <div style="font-weight:800;"><?= htmlspecialchars(date('F Y', strtotime($firstDay))) ?></div>
      <a class="btn secondary" href="bookings.php?month=<?= htmlspecialchars($nextMonth) ?>">Next →</a>
    </div>

    <!-- Calendar -->
    <div class="card" style="margin-bottom:12px;">
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:8px;font-weight:700;color:var(--muted);margin-bottom:8px;">
        <div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div><div>Sun</div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:8px;">
        <?php
        // Empty cells before day 1
        for ($i=1; $i<$startWeekday; $i++) {
          echo '<div class="card" style="min-height:70px;background:transparent;border:1px dashed var(--border);"></div>';
        }

        // Days
        for ($day=1; $day<=$daysInMonth; $day++) {
          $count = $dayCounts[$day];
          $bg = ($count > 0) ? 'background:#ecfdf5;border-color:#bbf7d0;' : '';
          $label = ($count > 0) ? "<div class='muted' style='margin-top:6px;font-size:12px;'>$count booking(s)</div>" : "<div class='muted' style='margin-top:6px;font-size:12px;'>No bookings</div>";

          echo "<div class='card' style='min-height:70px;$bg'>
                  <div style='font-weight:800;'>$day</div>
                  $label
                </div>";
        }
        ?>
      </div>
    </div>

    <!-- Booking list -->
    <div class="card">
      <h3 style="margin-top:0;">Bookings in/overlapping this month</h3>

      <?php if (empty($bookings)): ?>
        <p class="muted">No bookings found for this month.</p>
      <?php else: ?>
        <div style="overflow:auto;">
          <table style="width:100%;border-collapse:collapse;">
            <thead>
              <tr>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Student</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Room</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Start</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">End</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Status</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($bookings as $b): ?>
                <tr>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <?= htmlspecialchars($b['student_name']) ?> (<?= htmlspecialchars($b['sid']) ?>)
                  </td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <?= htmlspecialchars($b['room_no']) ?> - <?= htmlspecialchars($b['room_type']) ?>
                  </td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($b['start_date']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($b['end_date']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($b['status']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <?php if ($b['status'] === 'booked'): ?>
                      <a class="btn secondary" href="booking_cancel.php?id=<?= (int)$b['id'] ?>">Cancel</a>
                    <?php else: ?>
                      <span class="muted">—</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>