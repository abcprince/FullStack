<?php
// public/allocations.php
// Purpose: List all allocations (active + past) and provide check-in/checkout actions

$pageTitle = "Allocations";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';

// Fetch allocations with student + room info
$stmt = $pdo->query("
  SELECT a.*, s.student_id AS sid, s.name AS student_name, r.room_no, r.room_type
  FROM allocations a
  JOIN students s ON s.id = a.student_id
  JOIN rooms r ON r.id = a.room_id
  ORDER BY a.created_at DESC
");
$allocations = $stmt->fetchAll();
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
      <div>
        <h2 style="margin:0;">Allocations</h2>
        <p class="muted" style="margin:6px 0 0 0;">Assign students to rooms/beds and manage check-out.</p>
      </div>
      <a class="btn" href="allocation_add.php">+ New Check-in</a>
    </div>

    <div class="card">
      <?php if (empty($allocations)): ?>
        <p class="muted">No allocations yet. Click “New Check-in” to assign a student to a room.</p>
      <?php else: ?>
        <div style="overflow:auto;">
          <table style="width:100%;border-collapse:collapse;">
            <thead>
              <tr>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Student</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Room</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Bed</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Check-in</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Status</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($allocations as $a): ?>
                <tr>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <?= htmlspecialchars($a['student_name']) ?> (<?= htmlspecialchars($a['sid']) ?>)
                  </td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <?= htmlspecialchars($a['room_no']) ?> - <?= htmlspecialchars($a['room_type']) ?>
                  </td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= (int)$a['bed_no'] ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($a['checkin_date']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($a['allocation_status']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <?php if ($a['allocation_status'] === 'active'): ?>
                      <a class="btn secondary" href="allocation_checkout.php?id=<?= (int)$a['id'] ?>">Checkout</a>
                    <?php else: ?>
                      <span class="muted">—</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>