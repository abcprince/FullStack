<?php
// public/booking_cancel.php
// Purpose: Cancel a booking (soft cancel). Uses CSRF for safety.

$pageTitle = "Cancel Booking";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) die("Invalid booking ID.");

$stmt = $pdo->prepare("
  SELECT b.*, s.name AS student_name, s.student_id AS sid, r.room_no
  FROM bookings b
  JOIN students s ON s.id = b.student_id
  JOIN rooms r ON r.id = b.room_id
  WHERE b.id = ?
");
$stmt->execute([$id]);
$bk = $stmt->fetch();

if (!$bk) die("Booking not found.");

if ($bk['status'] !== 'booked') {
  die("Only booked bookings can be cancelled.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    $upd = $pdo->prepare("UPDATE bookings SET status='cancelled' WHERE id=?");
    $upd->execute([$id]);
    header("Location: bookings.php");
    exit;
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Cancel Booking</h2>
      <p class="muted" style="margin:6px 0 0 0;">This will free the room for others in that date range.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:750px;">
      <p>Cancel booking for:</p>
      <p><strong><?= htmlspecialchars($bk['student_name']) ?></strong> (<?= htmlspecialchars($bk['sid']) ?>)</p>
      <p class="muted">Room: <?= htmlspecialchars($bk['room_no']) ?> | <?= htmlspecialchars($bk['start_date']) ?> → <?= htmlspecialchars($bk['end_date']) ?></p>

      <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
        <button class="btn" type="submit">Yes, Cancel Booking</button>
        <a class="btn secondary" href="bookings.php">Back</a>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>