<?php
// public/search.php
// Purpose: Search across Students, Rooms, and Payments (mandatory search feature).
// Includes multi-criteria filters (extra marks).

$pageTitle = "Search";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';

// -------- Read query params (GET) --------
$tab = $_GET['tab'] ?? 'students'; // students | rooms | payments

// Students filters
$q_student = trim($_GET['q_student'] ?? '');

// Rooms filters
$room_type = trim($_GET['room_type'] ?? '');
$room_status = $_GET['room_status'] ?? ''; // available | maintenance | ''
$min_capacity = (int)($_GET['min_capacity'] ?? 0);

// Payments filters
$pay_status = $_GET['pay_status'] ?? ''; // paid | due | overdue | ''
$pay_month  = trim($_GET['pay_month'] ?? ''); // YYYY-MM
$pay_student_id = (int)($_GET['pay_student_id'] ?? 0);

// Dropdown data
$roomTypes = $pdo->query("SELECT DISTINCT room_type FROM rooms ORDER BY room_type ASC")->fetchAll();
$studentsList = $pdo->query("SELECT id, student_id, name FROM students ORDER BY name ASC")->fetchAll();

// -------- Results holders --------
$studentsRes = [];
$roomsRes = [];
$paymentsRes = [];

// -------- Execute searches based on selected tab --------
if ($tab === 'students') {
  if ($q_student !== '') {
    // Search by name OR student_id OR phone (prepared statement + wildcard)
    $like = "%$q_student%";
    $stmt = $pdo->prepare("
      SELECT * FROM students
      WHERE name LIKE ? OR student_id LIKE ? OR phone LIKE ?
      ORDER BY name ASC
      LIMIT 50
    ");
    $stmt->execute([$like, $like, $like]);
    $studentsRes = $stmt->fetchAll();
  }

} elseif ($tab === 'rooms') {
  // Rooms search with availability
  $sql = "
    SELECT
      r.id, r.room_no, r.room_type, r.capacity, r.price, r.status,
      (r.capacity - COALESCE(a.active_count,0)) AS beds_available
    FROM rooms r
    LEFT JOIN (
      SELECT room_id, COUNT(*) AS active_count
      FROM allocations
      WHERE allocation_status='active'
      GROUP BY room_id
    ) a ON a.room_id = r.id
    WHERE 1=1
  ";
  $params = [];

  if ($room_type !== '') {
    $sql .= " AND r.room_type = ? ";
    $params[] = $room_type;
  }
  if ($room_status !== '' && in_array($room_status, ['available','maintenance'], true)) {
    $sql .= " AND r.status = ? ";
    $params[] = $room_status;
  }
  if ($min_capacity > 0) {
    $sql .= " AND r.capacity >= ? ";
    $params[] = $min_capacity;
  }

  $sql .= " ORDER BY r.room_no ASC LIMIT 100";
  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $roomsRes = $stmt->fetchAll();

} elseif ($tab === 'payments') {
  // Payments search with optional filters
  $sql = "
    SELECT p.*, s.name AS student_name, s.student_id AS sid
    FROM payments p
    JOIN students s ON s.id = p.student_id
    WHERE 1=1
  ";
  $params = [];

  if ($pay_student_id > 0) {
    $sql .= " AND p.student_id = ? ";
    $params[] = $pay_student_id;
  }
  if ($pay_status !== '' && in_array($pay_status, ['paid','due','overdue'], true)) {
    $sql .= " AND p.status = ? ";
    $params[] = $pay_status;
  }
  if ($pay_month !== '' && preg_match('/^\d{4}-\d{2}$/', $pay_month)) {
    $sql .= " AND p.pay_month = ? ";
    $params[] = $pay_month;
  }

  $sql .= " ORDER BY p.created_at DESC LIMIT 100";
  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $paymentsRes = $stmt->fetchAll();
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Search</h2>
      <p class="muted" style="margin:6px 0 0 0;">Search students, rooms, and payments with filters.</p>
    </div>

    <!-- Tabs -->
    <div class="card" style="margin-bottom:12px;">
      <a class="btn secondary" href="search.php?tab=students">Students</a>
      <a class="btn secondary" href="search.php?tab=rooms" style="margin-left:8px;">Rooms</a>
      <a class="btn secondary" href="search.php?tab=payments" style="margin-left:8px;">Payments</a>
    </div>

    <?php if ($tab === 'students'): ?>
      <!-- STUDENT SEARCH -->
      <div class="card" style="margin-bottom:12px;">
        <h3 style="margin-top:0;">Search Students</h3>
        <form method="GET" action="">
          <input type="hidden" name="tab" value="students">
          <div class="form-row">
            <label>Search (Name / Student ID / Phone)</label>
            <input type="text" name="q_student" value="<?= htmlspecialchars($q_student) ?>" placeholder="e.g. 2513257 or Ram or 98..." required>
          </div>
          <button class="btn" type="submit">Search</button>
        </form>
      </div>

      <div class="card">
        <h3 style="margin-top:0;">Results</h3>
        <?php if ($q_student === ''): ?>
          <p class="muted">Enter a keyword and search.</p>
        <?php elseif (empty($studentsRes)): ?>
          <p class="muted">No students found.</p>
        <?php else: ?>
          <div style="overflow:auto;">
            <table style="width:100%;border-collapse:collapse;">
              <thead>
                <tr>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Student ID</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Name</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Email</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Phone</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($studentsRes as $s): ?>
                  <tr>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($s['student_id']) ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($s['name']) ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($s['email']) ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($s['phone']) ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($s['status']) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

    <?php elseif ($tab === 'rooms'): ?>
      <!-- ROOMS SEARCH -->
      <div class="card" style="margin-bottom:12px;">
        <h3 style="margin-top:0;">Search Rooms</h3>
        <form method="GET" action="">
          <input type="hidden" name="tab" value="rooms">

          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">
            <div>
              <label>Room Type</label>
              <select name="room_type">
                <option value="">All</option>
                <?php foreach ($roomTypes as $t): ?>
                  <option value="<?= htmlspecialchars($t['room_type']) ?>" <?= ($room_type === $t['room_type'])?'selected':'' ?>>
                    <?= htmlspecialchars($t['room_type']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div>
              <label>Status</label>
              <select name="room_status">
                <option value="">All</option>
                <option value="available" <?= $room_status==='available'?'selected':'' ?>>Available</option>
                <option value="maintenance" <?= $room_status==='maintenance'?'selected':'' ?>>Maintenance</option>
              </select>
            </div>

            <div>
              <label>Min Capacity</label>
              <input type="number" name="min_capacity" min="0" value="<?= (int)$min_capacity ?>">
            </div>
          </div>

          <div style="margin-top:12px;">
            <button class="btn" type="submit">Search</button>
          </div>
        </form>
      </div>

      <div class="card">
        <h3 style="margin-top:0;">Results</h3>
        <?php if (empty($roomsRes)): ?>
          <p class="muted">No rooms match your filters.</p>
        <?php else: ?>
          <div style="overflow:auto;">
            <table style="width:100%;border-collapse:collapse;">
              <thead>
                <tr>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Room No</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Type</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Capacity</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Beds Available</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($roomsRes as $r): ?>
                  <tr>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($r['room_no']) ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($r['room_type']) ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= (int)$r['capacity'] ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= (int)$r['beds_available'] ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($r['status']) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

    <?php else: ?>
      <!-- PAYMENTS SEARCH -->
      <div class="card" style="margin-bottom:12px;">
        <h3 style="margin-top:0;">Search Payments</h3>
        <form method="GET" action="">
          <input type="hidden" name="tab" value="payments">

          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">
            <div>
              <label>Student</label>
              <select name="pay_student_id">
                <option value="0">All</option>
                <?php foreach ($studentsList as $s): ?>
                  <option value="<?= (int)$s['id'] ?>" <?= ($pay_student_id === (int)$s['id'])?'selected':'' ?>>
                    <?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['student_id']) ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div>
              <label>Status</label>
              <select name="pay_status">
                <option value="">All</option>
                <option value="paid" <?= $pay_status==='paid'?'selected':'' ?>>Paid</option>
                <option value="due" <?= $pay_status==='due'?'selected':'' ?>>Due</option>
                <option value="overdue" <?= $pay_status==='overdue'?'selected':'' ?>>Overdue</option>
              </select>
            </div>

            <div>
              <label>Month</label>
              <input type="month" name="pay_month" value="<?= htmlspecialchars($pay_month) ?>">
            </div>
          </div>

          <div style="margin-top:12px;">
            <button class="btn" type="submit">Search</button>
          </div>
        </form>
      </div>

      <div class="card">
        <h3 style="margin-top:0;">Results</h3>
        <?php if (empty($paymentsRes)): ?>
          <p class="muted">No payments match your filters.</p>
        <?php else: ?>
          <div style="overflow:auto;">
            <table style="width:100%;border-collapse:collapse;">
              <thead>
                <tr>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Student</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Month</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Amount</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Due</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Paid</th>
                  <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($paymentsRes as $p): ?>
                  <tr>
                    <td style="padding:10px;border-bottom:1px solid var(--border);">
                      <?= htmlspecialchars($p['student_name']) ?> (<?= htmlspecialchars($p['sid']) ?>)
                    </td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($p['pay_month']) ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= number_format((float)$p['amount'],2) ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($p['due_date']) ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($p['paid_date'] ?? '-') ?></td>
                    <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($p['status']) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

    <?php endif; ?>

  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>