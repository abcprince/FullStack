<?php
// public/rooms.php
// Purpose: List all rooms and provide links to add/edit/delete

$pageTitle = "Rooms";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';

// Fetch all rooms
$stmt = $pdo->query("SELECT * FROM rooms ORDER BY room_no ASC");
$rooms = $stmt->fetchAll();
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
      <div>
        <h2 style="margin:0;">Rooms</h2>
        <p class="muted" style="margin:6px 0 0 0;">Manage hostel rooms (type, capacity, price, status).</p>
      </div>
      <a class="btn" href="room_add.php">+ Add Room</a>
    </div>

    <div class="card">
      <?php if (empty($rooms)): ?>
        <p class="muted">No rooms found. Click “Add Room” to create your first room.</p>
      <?php else: ?>
        <div style="overflow:auto;">
          <table style="width:100%;border-collapse:collapse;">
            <thead>
              <tr>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Room No</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Type</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Capacity</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Price</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Status</th>
                <th style="text-align:left;padding:10px;border-bottom:1px solid var(--border);">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rooms as $r): ?>
                <tr>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($r['room_no']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($r['room_type']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= (int)$r['capacity'] ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= number_format((float)$r['price'], 2) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);"><?= htmlspecialchars($r['status']) ?></td>
                  <td style="padding:10px;border-bottom:1px solid var(--border);">
                    <a class="btn secondary" href="room_edit.php?id=<?= (int)$r['id'] ?>">Edit</a>
                    <a class="btn secondary" href="room_delete.php?id=<?= (int)$r['id'] ?>">Delete</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>