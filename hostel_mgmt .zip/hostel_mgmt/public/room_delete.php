<?php
// public/room_delete.php
// Purpose: Confirm and delete a room safely (block if room has active allocations)

$pageTitle = "Delete Room";

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
  die("Invalid room ID.");
}

// Fetch room
$stmt = $pdo->prepare("SELECT * FROM rooms WHERE id = ?");
$stmt->execute([$id]);
$room = $stmt->fetch();

if (!$room) {
  die("Room not found.");
}

// Check if room has active allocations
$check = $pdo->prepare("SELECT COUNT(*) AS c FROM allocations WHERE room_id=? AND allocation_status='active'");
$check->execute([$id]);
$activeAlloc = (int)($check->fetch()['c'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } elseif ($activeAlloc > 0) {
    $error = "Cannot delete this room because it has active allocations.";
  } else {
    $del = $pdo->prepare("DELETE FROM rooms WHERE id = ?");
    $del->execute([$id]);
    header("Location: rooms.php");
    exit;
  }
}
?>

<div class="layout">
  <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

  <div>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0;">Delete Room</h2>
      <p class="muted" style="margin:6px 0 0 0;">This action cannot be undone.</p>
    </div>

    <?php if ($error): ?>
      <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:650px;">
      <p>Are you sure you want to delete room:</p>
      <p><strong><?= htmlspecialchars($room['room_no']) ?></strong> (<?= htmlspecialchars($room['room_type']) ?>)</p>

      <?php if ($activeAlloc > 0): ?>
        <div class="alert" style="margin-top:12px;">
          This room has <strong><?= $activeAlloc ?></strong> active allocation(s). You must checkout students first.
        </div>
        <div style="margin-top:12px;">
          <a class="btn secondary" href="rooms.php">Back</a>
        </div>
      <?php else: ?>
        <form method="POST" action="">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
          <button class="btn" type="submit">Yes, Delete</button>
          <a class="btn secondary" href="rooms.php">Cancel</a>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>