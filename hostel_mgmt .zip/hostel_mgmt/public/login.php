<?php
// public/login.php
// Purpose: Log the admin/staff into the system using sessions + password verification

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../config/session.php';

$pageTitle = "Login";

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // 1) CSRF check
  if (!csrf_validate($_POST['csrf_token'] ?? null)) {
    $error = "Security check failed. Please refresh and try again.";
  } else {
    // 2) Read inputs
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if ($email === '' || $pass === '') {
      $error = "Email and password are required.";
    } else {
      // 3) Fetch admin by email (prepared statement)
      $stmt = $pdo->prepare("SELECT id, name, email, password_hash, role FROM admins WHERE email = ? LIMIT 1");
      $stmt->execute([$email]);
      $user = $stmt->fetch();

      // 4) Verify password
      if ($user && password_verify($pass, $user['password_hash'])) {
        // 5) Prevent session fixation
        session_regenerate_id(true);

        // 6) Save session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role'];

        // 7) Redirect to dashboard
        header("Location: index.php");
        exit;
      } else {
        // Generic error message (don’t reveal if email exists)
        $error = "Invalid email or password.";
      }
    }
  }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card" style="max-width:520px;margin:0 auto;">
  <h2>Login</h2>

  <?php if ($error): ?>
    <div class="alert" style="margin-bottom:12px;"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST" action="">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">

    <div class="form-row">
      <label>Email</label>
      <input type="email" name="email" required>
    </div>

    <div class="form-row">
      <label>Password</label>
      <input type="password" name="password" required>
    </div>

    <button class="btn" type="submit">Login</button>
    <a class="btn secondary" href="register_admin.php">Create First Admin</a>

    <a class="btn secondary" href="student_login.php">Student Login</a>

    <a class="btn secondary" href="landing.php">Home</a>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>