<?php
// public/landing.php
// Purpose: Public landing page (no login required)

require_once __DIR__ . '/../config/db.php';

// Show "Create First Admin" only if no admins exist
$adminCount = 0;
try {
  $adminCount = (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
} catch (Exception $e) {
  $adminCount = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Hostel Management</title>
  <link rel="stylesheet" href="/hostel_mgmt/assets/css/style.css">

  <style>
    /* Landing-only styling (keeps your global css untouched) */
    body{
      background:
        radial-gradient(900px 500px at 25% 15%, rgba(16,185,129,.18), transparent 60%),
        radial-gradient(900px 500px at 80% 25%, rgba(34,197,94,.12), transparent 55%),
        radial-gradient(700px 450px at 50% 90%, rgba(20,184,166,.10), transparent 55%),
        #07110e;
      color: #e7fff5;
      min-height: 100vh;
    }
    .topbar{
      display:flex;justify-content:space-between;align-items:center;
      padding:18px 28px;
      border-bottom:1px solid rgba(255,255,255,.08);
      background: rgba(7,17,14,.55);
      backdrop-filter: blur(10px);
      position: sticky; top: 0; z-index: 20;
    }
    .brand{
      display:flex;align-items:center;gap:10px;font-weight:900;letter-spacing:.3px;
    }
    .brand-badge{
      width:34px;height:34px;border-radius:10px;
      background: linear-gradient(135deg, rgba(16,185,129,.35), rgba(34,197,94,.15));
      border:1px solid rgba(255,255,255,.12);
      display:grid;place-items:center;
      box-shadow: 0 10px 25px rgba(0,0,0,.35);
    }
    .nav{
      display:flex;gap:10px;align-items:center;
    }
    .nav a{
      text-decoration:none;
      padding:10px 14px;border-radius:12px;
      color:#dfffee;
      border:1px solid rgba(255,255,255,.10);
      background: rgba(255,255,255,.04);
      transition:.15s ease;
      font-weight:700;
    }
    .nav a:hover{
      transform: translateY(-1px);
      background: rgba(16,185,129,.12);
      border-color: rgba(16,185,129,.30);
    }
    .nav a.primary{
      background: rgba(16,185,129,.18);
      border-color: rgba(16,185,129,.35);
    }

    .hero{
      max-width: 1100px;
      margin: 56px auto 0;
      padding: 0 20px;
      text-align:center;
    }
    .pill{
      display:inline-flex;gap:10px;align-items:center;
      padding:8px 14px;border-radius:999px;
      border:1px solid rgba(16,185,129,.25);
      background: rgba(16,185,129,.10);
      color:#baffdf;
      font-weight:800;
      font-size: 13px;
    }
    .hero h1{
      margin:18px 0 10px;
      font-size: 46px;
      line-height: 1.05;
      letter-spacing: -0.8px;
      text-shadow: 0 20px 60px rgba(0,0,0,.45);
    }
    .hero p{
      margin: 0 auto;
      max-width: 820px;
      color: rgba(231,255,245,.78);
      font-weight: 600;
      line-height: 1.6;
    }
    .cta{
      margin-top: 18px;
      display:flex;
      justify-content:center;
      gap: 12px;
      flex-wrap: wrap;
    }
    .cta a{
      text-decoration:none;
      padding: 12px 16px;
      border-radius: 14px;
      font-weight: 900;
      border:1px solid rgba(255,255,255,.10);
      background: rgba(255,255,255,.04);
      color:#eafff6;
      transition:.15s ease;
    }
    .cta a:hover{
      transform: translateY(-1px);
      border-color: rgba(16,185,129,.30);
      background: rgba(16,185,129,.12);
    }
    .cta a.solid{
      background: rgba(16,185,129,.22);
      border-color: rgba(16,185,129,.40);
    }

    .grid{
      max-width: 1100px;
      margin: 36px auto 60px;
      padding: 0 20px;
      display:grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 14px;
    }
    .card2{
      border-radius: 18px;
      border: 1px solid rgba(255,255,255,.10);
      background: rgba(255,255,255,.04);
      padding: 16px;
      box-shadow: 0 20px 60px rgba(0,0,0,.35);
    }
    .card2 .icon{
      width:40px;height:40px;border-radius:14px;
      display:grid;place-items:center;
      background: rgba(16,185,129,.14);
      border: 1px solid rgba(16,185,129,.28);
      margin-bottom: 12px;
      font-weight:900;
    }
    .card2 h3{ margin:0 0 6px; }
    .card2 p{ margin:0; color: rgba(231,255,245,.75); line-height:1.6; font-weight:600; }

    .note{
      grid-column: span 3;
      display:flex;justify-content:space-between;align-items:center;gap:14px;
    }
    .note b{ color:#baffdf; }

    @media (max-width: 900px){
      .grid{ grid-template-columns: 1fr; }
      .note{ grid-column: auto; flex-direction:column; align-items:flex-start; }
      .hero h1{ font-size: 36px; }
    }
  </style>
</head>

<body>
  <div class="topbar">
    <div class="brand">
      <div class="brand-badge">🏠</div>
      <div>Hostel Management</div>
    </div>

    <div class="nav">
      <a class="primary" href="landing.php">Home</a>
      <a href="login.php">Admin/Staff Login</a>
      <a href="student_login.php">Student Login</a>
      <?php if ($adminCount === 0): ?>
        <a href="register_admin.php">Create First Admin</a>
      <?php endif; ?>
    </div>
  </div>

  <div class="hero">
    <div class="pill">🌿 Emerald UI • Secure CRUD • Live Availability (AJAX)</div>
    <h1>Manage Your Hostel, Effortlessly.</h1>
    <p>
      A clean hostel management system to manage rooms, students, allocations, payments, and bookings —
      with secure authentication, role separation, and real-time availability checks.
    </p>

    <div class="cta">
      <a class="solid" href="login.php">Admin/Staff Login</a>
      <a href="student_login.php">Student Login</a>
      <?php if ($adminCount === 0): ?>
        <a href="register_admin.php">Create First Admin</a>
      <?php endif; ?>
    </div>
  </div>

  <div class="grid">
    <div class="card2">
      <div class="icon">⚡</div>
      <h3>Live AJAX Availability</h3>
      <p>Rooms update instantly based on selected date range — no page reload.</p>
    </div>

    <div class="card2">
      <div class="icon">🛡️</div>
      <h3>Secure System</h3>
      <p>Prepared statements, output escaping, CSRF protection, and session-based access control.</p>
    </div>

    <div class="card2">
      <div class="icon">📅</div>
      <h3>Booking Calendar</h3>
      <p>Students can book rooms. Admin/staff see bookings in a calendar + list view.</p>
    </div>

    <div class="card2 note">
      <div>
        <div style="font-weight:900;font-size:16px;margin-bottom:4px;">✅ Quick Tip</div>
        <div style="color:rgba(231,255,245,.75);font-weight:650;">
          Admin can enable student login from the <b>Students → Edit</b> page and set a password.
        </div>
      </div>
      <a class="nav a primary" style="padding:10px 14px;border-radius:12px;text-decoration:none;"
         href="student_login.php">Try Student Portal</a>
    </div>
  </div>
</body>
</html>