<?php
session_start();
session_unset();
session_destroy();
header("Location: /hostel_mgmt/public/student_login.php");
exit;